"""Smart-money auto-discovery engine.

THE IDEA (bottom-up, no paid data needed):
Arkham/gmgn discover smart money top-down by indexing the whole chain and
ranking every wallet's PnL. We can't index the chain on one VPS. Instead we
discover smart money BOTTOM-UP from our own winning signals:

  1. Our outcome tracker already records which alerted tokens pumped (peak_pnl_pct).
  2. For each WINNER (>= WIN_THRESHOLD_PCT), pull the token's earliest buyers
     from on-chain data via Helius RPC.
  3. Wallets that show up as early buyers of MULTIPLE winners are, by revealed
     behaviour, smart money — they were early on tokens that worked.
  4. Auto-promote a wallet to the tracked list once it has hit
     MIN_WINS_TO_PROMOTE separate winners. Trust score scales with hit count.

This is self-improving: the longer the bot runs, the better its wallet list,
with zero manual curation and zero paid APIs. It is a genuine, if slower,
analogue of what the big platforms do.

Optional external seeding (best-effort, may be blocked): if a public leaderboard
endpoint is reachable, we ingest it as a cold-start. We NEVER hard-depend on it.
"""
import os
import json
import time
import logging
import threading
from collections import defaultdict
from typing import Dict, List, Tuple, Optional

import config
import smart_money
from http_utils import http_post

log = logging.getLogger("SolSniper")

# ─── Tunables ───
WIN_THRESHOLD_PCT      = float(os.environ.get("DISCOVERY_WIN_PCT", "100"))   # token must have +100% peak to count as a "winner"
EARLY_BUYER_LIMIT      = int(os.environ.get("DISCOVERY_EARLY_BUYERS", "40")) # how many earliest sigs to scan per winner
MIN_WINS_TO_PROMOTE    = int(os.environ.get("DISCOVERY_MIN_WINS", "2"))      # appear as early buyer of N winners → promote
MAX_AUTO_WALLETS       = int(os.environ.get("DISCOVERY_MAX_WALLETS", "150")) # cap auto-list size
DISCOVERY_INTERVAL_SEC = int(os.environ.get("DISCOVERY_INTERVAL_SEC", "3600"))  # run hourly
SOL_MINT               = "So11111111111111111111111111111111111111112"

# Persistent record of wallet → set of winning tokens it was early on
CANDIDATES_FILE = os.path.join(os.path.dirname(config.DB_PATH), "wallet_candidates.json")
_lock = threading.Lock()


def _load_candidates() -> Dict[str, List[str]]:
    if not os.path.exists(CANDIDATES_FILE):
        return {}
    try:
        with open(CANDIDATES_FILE) as f:
            return json.load(f)
    except Exception as e:
        log.error(f"candidates load error: {e}")
        return {}


def _save_candidates(data: Dict[str, List[str]]):
    os.makedirs(os.path.dirname(CANDIDATES_FILE), exist_ok=True)
    tmp = CANDIDATES_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, CANDIDATES_FILE)


# ─────────────────────────────────────────
# On-chain: earliest buyers of a token
# ─────────────────────────────────────────
def get_signatures_oldest_first(mint: str, limit: int) -> List[str]:
    """Walk getSignaturesForAddress backwards in time to find the OLDEST sigs.
    We page until we have <= limit*3 then take the tail (earliest)."""
    collected: List[Dict] = []
    before = None
    # page up to 5 times (1000 sigs max) to reach early history of a young token
    for _ in range(5):
        params = [mint, {"limit": 200}]
        if before:
            params[1]["before"] = before
        r = http_post(config.SOLANA_RPC, json_body={
            "jsonrpc": "2.0", "id": 1,
            "method": "getSignaturesForAddress", "params": params,
        }, timeout=12, retries=2)
        batch = (r or {}).get("result", []) or []
        if not batch:
            break
        collected.extend(batch)
        before = batch[-1]["signature"]
        if len(batch) < 200:
            break
    # earliest sigs are at the END of the time-descending list
    earliest = collected[-limit:] if len(collected) > limit else collected
    return [s["signature"] for s in earliest]


def early_buyers_of(mint: str) -> List[str]:
    """Return distinct wallet addresses that were among the earliest buyers."""
    sigs = get_signatures_oldest_first(mint, EARLY_BUYER_LIMIT)
    buyers: List[str] = []
    seen = set()
    for sig in sigs:
        tx = smart_money.get_transaction(sig)
        if not tx:
            continue
        # find any account whose token balance for `mint` increased and who spent SOL
        try:
            meta = tx["meta"]
            if meta.get("err"):
                continue
            pre = {(tb["owner"], tb["mint"]): float(tb["uiTokenAmount"]["uiAmount"] or 0)
                   for tb in meta.get("preTokenBalances", [])}
            post = {(tb["owner"], tb["mint"]): float(tb["uiTokenAmount"]["uiAmount"] or 0)
                    for tb in meta.get("postTokenBalances", [])}
            for (owner, m), pamt in post.items():
                if m != mint:
                    continue
                if pamt - pre.get((owner, m), 0) > 0:  # received this token
                    if owner and owner not in seen:
                        seen.add(owner)
                        buyers.append(owner)
        except Exception as e:
            log.debug(f"early_buyers parse error: {e}")
        time.sleep(0.15)  # gentle on free RPC
    return buyers


# ─────────────────────────────────────────
# Winners from our own outcome tracker
# ─────────────────────────────────────────
def get_winning_tokens() -> List[str]:
    """Pull token addresses whose peak PnL exceeded WIN_THRESHOLD_PCT."""
    try:
        import outcome_tracker
        with outcome_tracker._conn() as conn:
            rows = conn.execute(
                "SELECT address, peak_pnl_pct FROM signal_outcomes "
                "WHERE peak_pnl_pct >= ? ORDER BY peak_pnl_pct DESC LIMIT 200",
                (WIN_THRESHOLD_PCT,),
            ).fetchall()
        return [r["address"] for r in rows if r["address"]]
    except Exception as e:
        log.error(f"get_winning_tokens error: {e}")
        return []


# ─────────────────────────────────────────
# Discovery pass
# ─────────────────────────────────────────
def run_discovery_pass() -> int:
    """One full pass. Returns number of wallets newly promoted."""
    winners = get_winning_tokens()
    if not winners:
        log.info("[Discovery] No winning tokens yet — need pumped signals first.")
        return 0

    log.info(f"[Discovery] Analyzing {len(winners)} winning tokens for early buyers…")
    candidates = _load_candidates()

    for mint in winners:
        try:
            buyers = early_buyers_of(mint)
        except Exception as e:
            log.debug(f"[Discovery] {mint[:8]} buyer scan failed: {e}")
            continue
        for w in buyers:
            wins = set(candidates.get(w, []))
            if mint not in wins:
                wins.add(mint)
                candidates[w] = list(wins)

    _save_candidates(candidates)

    # Promote wallets that cleared the bar
    promoted = 0
    existing = {row[0] for row in smart_money.load_wallets()}
    # rank candidates by number of winning tokens they hit
    ranked = sorted(candidates.items(), key=lambda kv: len(kv[1]), reverse=True)
    for wallet, wins in ranked:
        if len([row for row in smart_money.load_wallets()]) >= MAX_AUTO_WALLETS:
            break
        if wallet in existing:
            continue
        if len(wins) >= MIN_WINS_TO_PROMOTE:
            trust = min(10, 4 + len(wins))  # more winners → higher trust
            if smart_money.add_wallet(wallet, label=f"auto-{len(wins)}w", trust=trust):
                promoted += 1
                existing.add(wallet)
                log.info(f"[Discovery] ✅ Promoted {wallet[:8]}… ({len(wins)} winners, trust {trust})")

    if promoted:
        try:
            import telegram
            telegram.send(f"🧠 *Smart-money discovery*: promoted {promoted} new wallet(s) "
                          f"found as early buyers of winning tokens. "
                          f"Now tracking {len(smart_money.load_wallets())}.")
        except Exception:
            pass
    log.info(f"[Discovery] Pass complete. Promoted {promoted} wallet(s).")
    return promoted


def discovery_loop(state: Dict):
    log.info(f"[Discovery] Auto-discovery loop started (every {DISCOVERY_INTERVAL_SEC//60} min, "
             f"win≥{WIN_THRESHOLD_PCT:.0f}%, promote≥{MIN_WINS_TO_PROMOTE} winners).")
    # small initial delay so the rest of the bot boots first
    for _ in range(60):
        if not state.get("running", True):
            return
        time.sleep(1)
    while state.get("running", True):
        try:
            run_discovery_pass()
        except Exception as e:
            log.error(f"[Discovery] pass error: {e}")
        # sleep in small chunks so shutdown is responsive
        for _ in range(DISCOVERY_INTERVAL_SEC // 5):
            if not state.get("running", True):
                break
            time.sleep(5)
