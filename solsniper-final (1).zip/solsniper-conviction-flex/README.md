# SolSniper — Conviction Mode (Adaptive Cap)

The quality-first Solana meme coin alert system. **Smart throttling, never artificially capped.**

When the market is quiet, you get 0-2 alerts. When the market is on fire and 20 elite signals are firing, the bot sends them all. Exceptional signals (smart money convergence, score 95+) bypass every cap.

## The Adaptive Cap system

Three layers of throttling work together:

### Layer 1: Burst protection
- **3 alerts per 10-minute window**
- Prevents Telegram from rate-limiting you during spike moments
- Protects you from a 20-message flood at 14:32

### Layer 2: Hourly ceiling
- **8 alerts per hour**
- Soft limit during sustained activity
- Distributes alerts naturally across the day

### Layer 3: Tier-specific 24h caps
| Tier | 24h cap | Why |
|---|---|---|
| 🎯 **SNIPER** | **Unlimited** | These are elite signals — never throttle |
| 🟢 **BUY** | 12 | Throttles same-tier spam |
| 👀 **WATCH** | 4 | Lowest signal gets strictest cap |

### Exceptional bypass
**Any signal with 4+ smart wallets converging OR score ≥95 bypasses ALL caps** (except a tiny burst limit to prevent Telegram errors).

These are too rare and too important to throttle ever.

## Real-world examples

**Quiet day:** 2-4 alerts. Strict filters do their job.

**Active day:** 8-15 alerts. Mix of SNIPER and BUY tiers. Adaptive cap distributes them through the day.

**Frenzy day:** 20-30+ alerts. Almost all SNIPER tier (because all 4 layers are confirming during a rally). You don't miss anything during the windows that matter.

**Spam day:** Still capped at 8/hr + 12 BUY/24h. You won't get flooded with low-tier noise.

## Strict mode (when you want quiet)

Send `/flex off` in Telegram and the bot switches to hard cap: **10 alerts/day, all tiers combined.**

Use when:
- You're traveling and can't trade
- You're sleeping and don't want phone vibrations
- You're testing the strategy and want a controlled sample size

Send `/flex on` to re-enable adaptive mode (default).

## The Conviction Hierarchy

Every alert is one of three tiers:

| Tier | What it means | Frequency |
|---|---|---|
| 🎯 **SNIPER** | Score ≥90 + smart money confirmed (or 4 confirmation layers) | ~1-3/day |
| 🟢 **BUY** | Score ≥80 + 2 confirmation layers passed | ~3-5/day |
| 👀 **WATCH** | Interesting but missing a layer — context only | ~1-2/day |

Total: **5-10 signals/day** that genuinely deserve your attention.

## The confirmation layers

A signal must pass at least **2** of these to fire:

1. **filters_passed** — Strong market filters: $60k+ liquidity, $200k+ volume, +50%+ 1h change, healthy buy/sell ratio
2. **smart_money** — 2+ tracked profitable wallets bought within 15min
3. **velocity** — Rank climbed 15+ positions in <60min on DexScreener
4. **momentum** — Score ≥85 from intrinsic data
5. **social** — 10+ X/Twitter mentions today

Smart money confirmation counts as 2 layers (it's the strongest signal).

## Anti-rug fortress

The bot rejects any token that:
- Has mint or freeze authority active
- Has LP that isn't burned/locked
- Has top 10 holders owning >40% (was 50% in v3)
- Fails honeypot detection on any of 3 sources
- Has both RugCheck AND GoPlus APIs unreachable (cautious failure mode)

## Anti-wash-trade

Tokens are rejected if:
- Volume / Liquidity ratio < 0.7 (suggests fake volume)
- Average transaction size > $5,000 (suggests dev/whale-only trading)
- Buy/sell ratio < 1.8 (suggests no real buying pressure)

## Self-tuning reports

After 50+ tracked outcomes, the bot starts sending you daily analysis:

```
🧠 Self-Tuning Report  (87 signals analyzed)

Performance by score:
  • Score 70-79: 31% wins, -8% avg (12 signals)
  • Score 80-84: 52% wins, +14% avg (34 signals)
  • Score 85-89: 67% wins, +41% avg (28 signals)
  • Score 90-100: 78% wins, +98% avg (13 signals)

🏆 Top runners:
  • PEPESOL +412% (score 92)
  • WIFCAT +287% (score 88)

💡 Recommendations:
  📊 Strong tier separation: score 90-100 wins 78% vs
     70-79 wins 31%. Consider raising MIN_ALERT_SCORE.
```

You decide whether to adjust thresholds based on what's actually working.

## Optional: SNIPER broadcast channel

Set `BROADCAST_CHANNEL_ID` in `.env` to a Telegram channel you own. SNIPER-tier alerts automatically post there too (with wallet labels anonymized). This is how you build a public audience later — let the bot do it for you while you sleep.

## Deployment

```bash
scp solsniper-conviction.zip root@YOUR_VPS_IP:/tmp/
ssh root@YOUR_VPS_IP
cd /tmp && unzip solsniper-conviction.zip && cd solsniper-final
sudo bash deploy.sh
sudo nano /opt/solsniper/.env
sudo systemctl start solsniper solsniper-dashboard
sudo journalctl -u solsniper -f
```

## What to expect in the first 24 hours

- **Hour 1-3:** Probably 0-2 alerts. This is normal — Conviction Mode is selective by design.
- **Hour 3-12:** 1-4 alerts as good setups develop. Mostly BUY tier.
- **Hour 12-24:** 3-8 total alerts. Maybe 1 SNIPER tier if the market is active.

If you see 0 alerts after 12 hours, the market is quiet, not the bot. Check `/status` to confirm scans are happening.

If you see >15 alerts in 24h, something's misconfigured — check filter thresholds.

## Commands

| Command | What it does |
|---|---|
| `/status` | Bot state, daily alert count, scan stats |
| `/recent` | Last 10 alerts |
| `/performance` | Win-rate analytics (after 1h) |
| `/tuning` | Self-tuning analysis (after 50 outcomes) |
| `/smartmoney` | Top tokens smart wallets buying now |
| `/wallets` | List tracked smart wallets |
| `/addwallet <addr> [label]` | Add wallet to track |
| `/removewallet <addr>` | Remove wallet |
| `/pause` / `/resume` | Control alerts |
| `/help` | Show all commands |

## Maintenance

Effectively zero. Once deployed:
- Top up Vultr USDT every ~2 months (~$6/mo charge)
- Glance at `/performance` once a week
- Read self-tuning report once a day
- Adjust thresholds via `.env` if the data tells you to

That's it.

## Cost

| Item | Cost |
|---|---|
| Vultr 1 vCPU VPS | $6/mo |
| Everything else | Free |
| **Total** | **$6/month** |

## Engineering philosophy

This is a tool for someone who treats trading as a discipline, not a gambling habit. The bot will be quiet for hours sometimes. That's the point. Most retail bot users lose money because their bot shouts at them every 5 minutes and they trade emotionally. This bot is quiet for hours, then says one thing that matters.

If after 90 days your win rate is below 45% across 100+ alerts, the strategy isn't working for the current market — don't double down, re-evaluate. If it's above 55%, you have something real and we can talk about scale.

The bot's job is to be the best version it can be. Your job is the trading judgment.

## Files

```
solsniper-final/
├── bot.py              # Main — 7 threads
├── config.py           # Conviction Mode tuning
├── scanner.py          # Multi-layer confirmation pipeline
├── rug_check.py        # 3-source rug detection
├── smart_money.py      # Wallet tracking + multi-wallet confirmation
├── on_chain_monitor.py # Dev/LP/continuation alerts
├── outcome_tracker.py  # Win-rate measurement
├── self_tuner.py       # Daily tuning reports
├── trending.py         # Rank velocity
├── social.py           # X mentions
├── telegram.py         # Alerts + commands + broadcast
├── dashboard.py        # Flask web UI
├── db.py               # SQLite
├── http_utils.py       # Retry HTTP
├── deploy.sh           # One-shot VPS install
├── .env.example
├── requirements.txt
└── README.md
```
