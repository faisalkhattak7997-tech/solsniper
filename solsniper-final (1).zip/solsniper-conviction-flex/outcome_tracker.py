"""Signal outcome tracking — measures actual win rate over time.

For every alert we send, we record the price.
At 1h, 6h, and 24h later, we check the price again.
This builds a real performance record: "STRONG BUY at score 75+ wins 64% of the time".

This is the data that turns the bot from a script into a defensible product.
"""
import time
import logging
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Dict, List

import config
import db
from http_utils import http_get

log = logging.getLogger("SolSniper")

# We add a new table to the existing DB
@contextmanager
def _conn():
    c = sqlite3.connect(config.DB_PATH, timeout=15, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    try:
        yield c
        c.commit()
    finally:
        c.close()

def init_table():
    with _conn() as c:
        c.execute("""
        CREATE TABLE IF NOT EXISTS signal_outcomes (
            signal_id   INTEGER PRIMARY KEY,
            address     TEXT,
            symbol      TEXT,
            label       TEXT,
            score       INTEGER,
            initial_price REAL,
            alert_ts    REAL,
            price_1h    REAL,
            price_6h    REAL,
            price_24h   REAL,
            pnl_1h_pct  REAL,
            pnl_6h_pct  REAL,
            pnl_24h_pct REAL,
            peak_price  REAL,
            peak_pnl_pct REAL,
            checked_1h  INTEGER DEFAULT 0,
            checked_6h  INTEGER DEFAULT 0,
            checked_24h INTEGER DEFAULT 0
        );
        """)

def record_signal(signal_id: int, address: str, symbol: str, label: str,
                  score: int, initial_price: float):
    with _conn() as c:
        c.execute("""
            INSERT OR REPLACE INTO signal_outcomes
            (signal_id, address, symbol, label, score, initial_price, alert_ts, peak_price, peak_pnl_pct)
            VALUES(?,?,?,?,?,?,?,?,0)
        """, (signal_id, address, symbol, label, score, initial_price, time.time(), initial_price))

def get_current_price(address: str) -> float:
    data = http_get(f"https://api.dexscreener.com/latest/dex/tokens/{address}",
                    timeout=8, retries=1)
    if not data: return 0
    pairs = data.get("pairs", []) if isinstance(data, dict) else []
    sol_pairs = [p for p in pairs if p.get("chainId") == "solana"]
    if not sol_pairs: return 0
    pair = max(sol_pairs, key=lambda x: float((x.get("liquidity") or {}).get("usd") or 0))
    return float(pair.get("priceUsd") or 0)

def check_outcomes(state: Dict):
    """Background thread. Periodically checks outcomes for signals at 1h/6h/24h marks."""
    log.info("Outcome tracker started")
    while state.get("running", True):
        try:
            with _conn() as c:
                rows = c.execute("""
                    SELECT * FROM signal_outcomes
                    WHERE checked_24h=0 ORDER BY alert_ts ASC LIMIT 50
                """).fetchall()

            now = time.time()
            for row in rows:
                if not state.get("running", True): break
                age_sec = now - row["alert_ts"]

                # Determine what needs checking
                needs_1h = not row["checked_1h"] and age_sec >= 3600
                needs_6h = not row["checked_6h"] and age_sec >= 21600
                needs_24h = not row["checked_24h"] and age_sec >= 86400

                if not (needs_1h or needs_6h or needs_24h):
                    # Always update peak
                    cur_price = get_current_price(row["address"])
                    if cur_price > 0 and cur_price > (row["peak_price"] or 0):
                        peak_pnl = ((cur_price - row["initial_price"]) / row["initial_price"]) * 100
                        with _conn() as c:
                            c.execute("UPDATE signal_outcomes SET peak_price=?, peak_pnl_pct=? WHERE signal_id=?",
                                      (cur_price, peak_pnl, row["signal_id"]))
                    time.sleep(0.5)
                    continue

                cur_price = get_current_price(row["address"])
                if cur_price <= 0:
                    time.sleep(0.5); continue

                pnl_pct = ((cur_price - row["initial_price"]) / row["initial_price"]) * 100

                with _conn() as c:
                    if needs_1h:
                        c.execute("UPDATE signal_outcomes SET price_1h=?, pnl_1h_pct=?, checked_1h=1 WHERE signal_id=?",
                                  (cur_price, pnl_pct, row["signal_id"]))
                    if needs_6h:
                        c.execute("UPDATE signal_outcomes SET price_6h=?, pnl_6h_pct=?, checked_6h=1 WHERE signal_id=?",
                                  (cur_price, pnl_pct, row["signal_id"]))
                    if needs_24h:
                        c.execute("UPDATE signal_outcomes SET price_24h=?, pnl_24h_pct=?, checked_24h=1 WHERE signal_id=?",
                                  (cur_price, pnl_pct, row["signal_id"]))
                    # Update peak too
                    if cur_price > (row["peak_price"] or 0):
                        peak_pnl = ((cur_price - row["initial_price"]) / row["initial_price"]) * 100
                        c.execute("UPDATE signal_outcomes SET peak_price=?, peak_pnl_pct=? WHERE signal_id=?",
                                  (cur_price, peak_pnl, row["signal_id"]))
                time.sleep(0.5)
        except Exception as e:
            log.exception(f"Outcome tracker error: {e}")

        # Check every 5 minutes
        for _ in range(300):
            if not state.get("running", True): return
            time.sleep(1)

# ─────────────────────────────────────────
# Stats queries
# ─────────────────────────────────────────
def get_performance_stats() -> Dict:
    with _conn() as c:
        # Overall
        total = c.execute("SELECT COUNT(*) c FROM signal_outcomes WHERE checked_1h=1").fetchone()["c"]
        if total == 0:
            return {"total_tracked": 0, "win_rate_1h": None, "win_rate_24h": None}

        wins_1h = c.execute("SELECT COUNT(*) c FROM signal_outcomes WHERE checked_1h=1 AND pnl_1h_pct > 0").fetchone()["c"]
        wins_24h_total = c.execute("SELECT COUNT(*) c FROM signal_outcomes WHERE checked_24h=1").fetchone()["c"]
        wins_24h = c.execute("SELECT COUNT(*) c FROM signal_outcomes WHERE checked_24h=1 AND pnl_24h_pct > 0").fetchone()["c"]

        avg_1h = c.execute("SELECT AVG(pnl_1h_pct) v FROM signal_outcomes WHERE checked_1h=1").fetchone()["v"] or 0
        avg_peak = c.execute("SELECT AVG(peak_pnl_pct) v FROM signal_outcomes WHERE peak_pnl_pct IS NOT NULL").fetchone()["v"] or 0

        # By label
        by_label = {}
        for label in ("STRONG BUY", "BUY"):
            row = c.execute("""
                SELECT COUNT(*) c, AVG(pnl_1h_pct) avg_pnl,
                       SUM(CASE WHEN pnl_1h_pct > 0 THEN 1 ELSE 0 END) wins
                FROM signal_outcomes WHERE checked_1h=1 AND label=?
            """, (label,)).fetchone()
            n = row["c"] or 0
            by_label[label] = {
                "count": n,
                "win_rate": round((row["wins"] / n * 100), 1) if n else 0,
                "avg_pnl_1h": round(row["avg_pnl"] or 0, 1),
            }

        # Top winners (5)
        top = c.execute("""
            SELECT symbol, peak_pnl_pct FROM signal_outcomes
            WHERE peak_pnl_pct IS NOT NULL ORDER BY peak_pnl_pct DESC LIMIT 5
        """).fetchall()

    return {
        "total_tracked": total,
        "win_rate_1h": round((wins_1h / total * 100), 1),
        "win_rate_24h": round((wins_24h / wins_24h_total * 100), 1) if wins_24h_total else None,
        "avg_pnl_1h": round(avg_1h, 1),
        "avg_peak_pnl": round(avg_peak, 1),
        "by_label": by_label,
        "top_winners": [{"symbol": r["symbol"], "peak_pct": round(r["peak_pnl_pct"], 0)} for r in top],
    }
