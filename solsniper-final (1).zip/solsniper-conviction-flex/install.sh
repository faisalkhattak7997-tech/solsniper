#!/usr/bin/env bash
# SolSniper one-shot installer for Ubuntu 24.04 / 26.04
# Auto-detects system Python (no deadsnakes PPA needed).
set -euo pipefail

USER_NAME="solsniper"
APP_DIR="/opt/solsniper"

echo "═══════════════════════════════════════════════"
echo "  SolSniper Conviction Mode — One-Shot Install"
echo "═══════════════════════════════════════════════"

if [[ $EUID -ne 0 ]]; then echo "Run as root"; exit 1; fi

# Detect system python3 (Ubuntu 26.04 ships 3.12+)
PYTHON="$(command -v python3)"
echo ">> Using Python: $($PYTHON --version)"

echo ">> Installing system packages"
apt-get update -qq
apt-get install -y -qq python3-venv python3-dev build-essential curl ufw unzip >/dev/null 2>&1

# Create service user
if ! id "$USER_NAME" &>/dev/null; then
    useradd -m -s /bin/bash "$USER_NAME"
fi

echo ">> Installing bot to $APP_DIR"
mkdir -p "$APP_DIR"
cp -r ./* "$APP_DIR/" 2>/dev/null || true
chown -R "$USER_NAME:$USER_NAME" "$APP_DIR"

echo ">> Creating Python virtual environment"
sudo -u "$USER_NAME" $PYTHON -m venv "$APP_DIR/venv"
sudo -u "$USER_NAME" "$APP_DIR/venv/bin/pip" install --quiet --upgrade pip
sudo -u "$USER_NAME" "$APP_DIR/venv/bin/pip" install --quiet requests python-dotenv flask

mkdir -p "$APP_DIR/data" "$APP_DIR/logs"
chown -R "$USER_NAME:$USER_NAME" "$APP_DIR/data" "$APP_DIR/logs"

# .env is written by the bootstrap wrapper before this runs (see bootstrap)
if [[ ! -f "$APP_DIR/.env" ]]; then
    cp "$APP_DIR/.env.example" "$APP_DIR/.env"
fi
chmod 600 "$APP_DIR/.env"
chown "$USER_NAME:$USER_NAME" "$APP_DIR/.env"

# systemd: bot
cat > /etc/systemd/system/solsniper.service <<EOF
[Unit]
Description=SolSniper Bot
After=network.target
[Service]
Type=simple
User=$USER_NAME
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/venv/bin/python $APP_DIR/bot.py
Restart=always
RestartSec=10
StandardOutput=append:$APP_DIR/logs/bot.stdout.log
StandardError=append:$APP_DIR/logs/bot.stderr.log
[Install]
WantedBy=multi-user.target
EOF

# systemd: dashboard
cat > /etc/systemd/system/solsniper-dashboard.service <<EOF
[Unit]
Description=SolSniper Dashboard
After=network.target
[Service]
Type=simple
User=$USER_NAME
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/venv/bin/python $APP_DIR/dashboard.py
Restart=always
RestartSec=10
StandardOutput=append:$APP_DIR/logs/dashboard.log
StandardError=append:$APP_DIR/logs/dashboard.log
[Install]
WantedBy=multi-user.target
EOF

echo ">> Configuring firewall"
ufw --force reset >/dev/null 2>&1 || true
ufw default deny incoming >/dev/null
ufw default allow outgoing >/dev/null
ufw allow 22/tcp >/dev/null
ufw allow 8080/tcp >/dev/null
ufw --force enable >/dev/null

systemctl daemon-reload
systemctl enable solsniper.service solsniper-dashboard.service >/dev/null 2>&1
systemctl restart solsniper.service solsniper-dashboard.service

echo ""
echo "═══════════════════════════════════════════════"
echo "  ✅ SolSniper is INSTALLED and RUNNING"
echo "═══════════════════════════════════════════════"
echo "  Check Telegram for the online message."
echo "  Logs:  journalctl -u solsniper -f"
echo "  Dash:  http://$(curl -s ifconfig.me):8080/?token=<your token>"
echo ""
