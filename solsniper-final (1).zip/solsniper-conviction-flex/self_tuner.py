"""Self-tuning module.
After SELF_TUNE_AFTER_N_OUTCOMES tracked outcomes, analyze the data:
  - Which score buckets actually win?
  - Which confirmation layer combinations have the best win rate?
  - Log recommended threshold adjustments

This does NOT auto-change config in production — it logs and posts to Telegram
so the operator (Faisal) can decide. Auto-mutation in trading systems is risky
without human review.
"""
import logging
import sqlite3
import json
from contextlib import contextmanager
from typing import Dict, List, Optional

import config

log = logging.getLogger("SolSniper")

@contextmanager
def _conn():
    c = sqlite3.connect(config.DB_PATH, timeout=15, check_same_thread=False)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    finally:
        c.close()

def analyze_outcomes() -> Optional[Dict]:
    """Returns a recommendation dict, or None if not enough data."""
    with _conn() as c:
        # Need at least N closed outcomes
        total = c.execute("SELECT COUNT(*) c FROM signal_outcomes WHERE checked_1h=1").fetchone()["c"]
        if total < config.SELF_TUNE_AFTER_N_OUTCOMES:
            return None

        # Win rates by score bucket
        score_buckets = []
        for low, high in [(70, 79), (80, 84), (85, 89), (90, 100)]:
            row = c.execute("""
                SELECT COUNT(*) c,
                       SUM(CASE WHEN pnl_1h_pct > 0 THEN 1 ELSE 0 END) wins,
                       AVG(pnl_1h_pct) avg_pnl,
                       AVG(peak_pnl_pct) avg_peak
                FROM signal_outcomes
                WHERE checked_1h=1 AND score BETWEEN ? AND ?
            """, (low, high)).fetchone()
            n = row["c"] or 0
            if n >= 5:
                score_buckets.append({
                    "range": f"{low}-{high}",
                    "n": n,
                    "win_rate": round((row["wins"] / n * 100), 1),
                    "avg_pnl": round(row["avg_pnl"] or 0, 1),
                    "avg_peak": round(row["avg_peak"] or 0, 1),
                })

        # Top winners
        top = c.execute("""
            SELECT symbol, peak_pnl_pct, score FROM signal_outcomes
            WHERE peak_pnl_pct IS NOT NULL ORDER BY peak_pnl_pct DESC LIMIT 10
        """).fetchall()

        # Worst losers
        worst = c.execute("""
            SELECT symbol, pnl_1h_pct, score FROM signal_outcomes
            WHERE checked_1h=1 ORDER BY pnl_1h_pct ASC LIMIT 5
        """).fetchall()

    # Generate recommendation
    recommendation = []
    if score_buckets:
        # If lower-score band wins less than higher band by >20%, suggest raising
        if len(score_buckets) >= 2:
            low_band = score_buckets[0]  # 70-79
            high_band = score_buckets[-1]  # 90-100
            if high_band["win_rate"] - low_band["win_rate"] > 20:
                recommendation.append(
                    f"📊 Strong tier separation: score {high_band['range']} wins "
                    f"{high_band['win_rate']}% vs {low_band['range']} wins {low_band['win_rate']}%. "
                    f"Consider raising MIN_ALERT_SCORE."
                )
            elif low_band["win_rate"] > high_band["win_rate"]:
                recommendation.append(
                    f"📊 Surprise: lower scores winning more. Filters may be over-aggressive."
                )

    return {
        "total_tracked": total,
        "score_buckets": score_buckets,
        "top_winners": [{"symbol": r["symbol"], "peak": round(r["peak_pnl_pct"], 0), "score": r["score"]} for r in top],
        "worst_losers": [{"symbol": r["symbol"], "pnl": round(r["pnl_1h_pct"], 0), "score": r["score"]} for r in worst],
        "recommendations": recommendation,
    }

def format_tuning_report(analysis: Dict) -> str:
    """Generate Telegram message from analysis."""
    lines = [
        f"🧠 *Self-Tuning Report*  ({analysis['total_tracked']} signals analyzed)\n",
        "*Performance by score:*"
    ]
    for b in analysis["score_buckets"]:
        lines.append(f"  • Score {b['range']}: {b['win_rate']}% wins, {b['avg_pnl']:+.0f}% avg ({b['n']} signals)")

    if analysis["top_winners"]:
        lines.append("\n🏆 *Top runners:*")
        for w in analysis["top_winners"][:5]:
            lines.append(f"  • {w['symbol']} +{w['peak']:.0f}% (score {w['score']})")

    if analysis["worst_losers"]:
        lines.append("\n💔 *Worst losers:*")
        for w in analysis["worst_losers"][:3]:
            lines.append(f"  • {w['symbol']} {w['pnl']:+.0f}% (score {w['score']})")

    if analysis["recommendations"]:
        lines.append("\n💡 *Recommendations:*")
        for r in analysis["recommendations"]:
            lines.append(f"  {r}")

    return "\n".join(lines)
