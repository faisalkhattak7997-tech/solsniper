"""On-chain monitoring: dev wallet behavior, LP movements, holder velocity.

For each token we issue a signal for, we periodically check:
  1. Is the dev (creator) wallet still holding or dumping?
  2. Has the LP dropped significantly? (rug-pull early warning)
  3. How fast is the holder count growing?

If any of these hits an alert threshold, we push an EXIT or BOOST update to Telegram.
"""
import time
import logging
import threading
import requests
from typing import Dict, List, Optional, Tuple
from collections import defaultdict

import config
from http_utils import http_get, http_post

log = logging.getLogger("SolSniper")

# token_address → {
#   'first_seen_ts', 'initial_liq', 'initial_holders', 'dev_wallet', 'dev_initial_balance',
#   'last_liq', 'last_holders', 'last_check', 'warned': {...}
# }
_tracked: Dict[str, Dict] = {}
_lock = threading.Lock()

TRACK_DURATION_MIN = 120   # monitor each token for 2 hours after first alert
CHECK_INTERVAL_SEC = 30

# ─────────────────────────────────────────
# Dev wallet identification
# ─────────────────────────────────────────
def find_dev_wallet(token_address: str) -> Optional[str]:
    """Find the token's mint authority OR largest non-LP holder.
    Best heuristic: the wallet that received tokens FIRST after mint creation.
    Fallback: top non-LP holder.
    """
    try:
        # Get token metadata
        r = http_post(config.SOLANA_RPC, json_body={
            "jsonrpc": "2.0", "id": 1,
            "method": "getAccountInfo",
            "params": [token_address, {"encoding": "jsonParsed"}],
        }, timeout=10, retries=1)
        if not r or not r.get("result"):
            return None
        info = r["result"]["value"]["data"]["parsed"]["info"]
        mint_auth = info.get("mintAuthority")

        # Get largest accounts
        r2 = http_post(config.SOLANA_RPC, json_body={
            "jsonrpc": "2.0", "id": 1,
            "method": "getTokenLargestAccounts",
            "params": [token_address],
        }, timeout=10, retries=1)
        if not r2 or not r2.get("result"):
            return mint_auth

        accounts = r2["result"]["value"][:5]
        # The largest holder is usually the LP pool. Skip it.
        # The 2nd or 3rd often is the dev's reserve.
        for acc in accounts[1:4]:
            owner = _account_owner(acc.get("address"))
            if owner and owner != mint_auth:
                return owner
        return mint_auth
    except Exception as e:
        log.debug(f"find_dev_wallet error: {e}")
        return None

def _account_owner(token_account: str) -> Optional[str]:
    """Get the owner of a token account."""
    try:
        r = http_post(config.SOLANA_RPC, json_body={
            "jsonrpc": "2.0", "id": 1,
            "method": "getAccountInfo",
            "params": [token_account, {"encoding": "jsonParsed"}],
        }, timeout=10, retries=1)
        if not r or not r.get("result"):
            return None
        return r["result"]["value"]["data"]["parsed"]["info"].get("owner")
    except Exception:
        return None

def get_dev_token_balance(dev_wallet: str, token_address: str) -> float:
    """Get dev's current holdings of the token."""
    try:
        r = http_post(config.SOLANA_RPC, json_body={
            "jsonrpc": "2.0", "id": 1,
            "method": "getTokenAccountsByOwner",
            "params": [dev_wallet, {"mint": token_address}, {"encoding": "jsonParsed"}],
        }, timeout=10, retries=1)
        if not r or not r.get("result"):
            return 0
        accounts = r["result"]["value"]
        total = 0.0
        for a in accounts:
            ui = a["account"]["data"]["parsed"]["info"]["tokenAmount"].get("uiAmount")
            total += float(ui or 0)
        return total
    except Exception:
        return 0

# ─────────────────────────────────────────
# Tracking lifecycle
# ─────────────────────────────────────────
def start_tracking(token_address: str, initial_liq: float, initial_price: float):
    """Begin monitoring a token after we send an alert for it."""
    with _lock:
        if token_address in _tracked:
            return
        dev = find_dev_wallet(token_address)
        dev_balance = get_dev_token_balance(dev, token_address) if dev else 0
        _tracked[token_address] = {
            "first_seen_ts": time.time(),
            "initial_liq": initial_liq,
            "initial_price": initial_price,
            "dev_wallet": dev,
            "dev_initial_balance": dev_balance,
            "last_liq": initial_liq,
            "last_check": time.time(),
            "warned": set(),
        }
        log.info(f"📍 Tracking {token_address[:8]}... | LP ${initial_liq:,.0f} | dev {(dev or '?')[:8]}...")

def is_tracked(token_address: str) -> bool:
    with _lock:
        return token_address in _tracked

# ─────────────────────────────────────────
# Periodic checks
# ─────────────────────────────────────────
def get_current_pair_metrics(token_address: str) -> Optional[Tuple[float, float, int]]:
    """Get (liquidity_usd, price_usd, holder_count_approx) from DexScreener."""
    data = http_get(
        f"https://api.dexscreener.com/latest/dex/tokens/{token_address}",
        timeout=8, retries=1
    )
    if not data:
        return None
    pairs = data.get("pairs", []) if isinstance(data, dict) else []
    sol_pairs = [p for p in pairs if p.get("chainId") == "solana"]
    if not sol_pairs:
        return None
    pair = max(sol_pairs, key=lambda x: float((x.get("liquidity") or {}).get("usd") or 0))
    liq = float((pair.get("liquidity") or {}).get("usd") or 0)
    price = float(pair.get("priceUsd") or 0)
    return liq, price, 0  # DexScreener doesn't provide holder count directly

def check_token(token_address: str) -> List[Dict]:
    """Run all checks on one tracked token. Returns list of alert dicts."""
    alerts = []
    with _lock:
        t = _tracked.get(token_address)
        if not t:
            return alerts

    metrics = get_current_pair_metrics(token_address)
    if not metrics:
        return alerts
    cur_liq, cur_price, _ = metrics

    # 1. LP drop check
    if cur_liq < t["initial_liq"] * 0.7 and "lp_drop_30" not in t["warned"]:
        with _lock:
            t["warned"].add("lp_drop_30")
        alerts.append({
            "type": "LP_DROP",
            "token": token_address,
            "msg": f"⚠️ LP dropped {(1 - cur_liq/t['initial_liq'])*100:.0f}% "
                   f"(${t['initial_liq']:,.0f} → ${cur_liq:,.0f}) — possible rug",
            "severity": "high",
        })
    elif cur_liq < t["initial_liq"] * 0.5 and "lp_drop_50" not in t["warned"]:
        with _lock:
            t["warned"].add("lp_drop_50")
        alerts.append({
            "type": "LP_DRAIN",
            "token": token_address,
            "msg": f"🚨 LP HALVED in 2h — likely rug in progress (${cur_liq:,.0f} left)",
            "severity": "critical",
        })

    # 2. Dev wallet dump check (only if we know the dev wallet)
    if t.get("dev_wallet") and t["dev_initial_balance"] > 0:
        dev_current = get_dev_token_balance(t["dev_wallet"], token_address)
        sold_pct = (t["dev_initial_balance"] - dev_current) / t["dev_initial_balance"]
        if sold_pct >= 0.5 and "dev_dump_50" not in t["warned"]:
            with _lock:
                t["warned"].add("dev_dump_50")
            alerts.append({
                "type": "DEV_DUMP",
                "token": token_address,
                "msg": f"🚨 DEV WALLET DUMPING — sold {sold_pct*100:.0f}% of their bag, EXIT",
                "severity": "critical",
            })
        elif sold_pct >= 0.2 and "dev_dump_20" not in t["warned"]:
            with _lock:
                t["warned"].add("dev_dump_20")
            alerts.append({
                "type": "DEV_TRIM",
                "token": token_address,
                "msg": f"⚠️ Dev wallet sold {sold_pct*100:.0f}% — watch closely",
                "severity": "medium",
            })

    # 3. Strong continuation (price up significantly from entry)
    if cur_price >= t["initial_price"] * 2 and "continuation_2x" not in t["warned"]:
        with _lock:
            t["warned"].add("continuation_2x")
        alerts.append({
            "type": "CONTINUATION",
            "token": token_address,
            "msg": f"🚀 +100% from initial alert — momentum confirmed",
            "severity": "info",
        })
    elif cur_price >= t["initial_price"] * 5 and "continuation_5x" not in t["warned"]:
        with _lock:
            t["warned"].add("continuation_5x")
        alerts.append({
            "type": "CONTINUATION",
            "token": token_address,
            "msg": f"🚀🚀 +400% from initial alert — major runner",
            "severity": "info",
        })

    with _lock:
        t["last_liq"] = cur_liq
        t["last_check"] = time.time()

    return alerts

def expire_old():
    """Remove tokens we've been tracking for too long."""
    cutoff = time.time() - (TRACK_DURATION_MIN * 60)
    with _lock:
        for addr in list(_tracked.keys()):
            if _tracked[addr]["first_seen_ts"] < cutoff:
                del _tracked[addr]

# ─────────────────────────────────────────
# Background loop
# ─────────────────────────────────────────
def monitor_loop(state: Dict, telegram_send=None):
    """Background thread: check each tracked token every CHECK_INTERVAL_SEC seconds."""
    log.info("On-chain monitor started")
    while state.get("running", True):
        try:
            with _lock:
                tokens = list(_tracked.keys())

            for token_addr in tokens:
                if not state.get("running", True): break
                alerts = check_token(token_addr)
                for a in alerts:
                    log.info(f"  [{a['type']}] {token_addr[:8]}: {a['msg']}")
                    if telegram_send:
                        telegram_send(f"*FOLLOW-UP* on `{token_addr[:8]}...`\n\n{a['msg']}\n\n"
                                      f"[DexScreener](https://dexscreener.com/solana/{token_addr})")
                time.sleep(1)

            expire_old()
        except Exception as e:
            log.exception(f"Monitor loop error: {e}")

        for _ in range(CHECK_INTERVAL_SEC):
            if not state.get("running", True): break
            time.sleep(1)
