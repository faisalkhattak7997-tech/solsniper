"""SolSniper Conviction Mode scanner.

A signal must pass MULTIPLE independent confirmation layers to fire:
  1. filters_passed (always 1 if we got here)
  2. score_confirmed (>= 85)
  3. smart_money_confirmed (2+ tracked wallets)
  4. velocity_confirmed (rank climbed N+)
  5. social_confirmed (10+ X mentions)

Required: at least MIN_CONFIRMATION_LAYERS layers. Default 2.
Plus: rug check must pass, fake volume check must pass, per-token cooldown must clear,
daily alert cap must not be exceeded, time-of-day requirement must be met.
"""
import time
import logging
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any, Tuple

import config
from http_utils import http_get
from rug_check import comprehensive_rug_check
import smart_money
import social
import trending

log = logging.getLogger("SolSniper")

# ─────────────────────────────────────────
# ADAPTIVE RATE LIMITER
# ─────────────────────────────────────────
# In-memory rolling history of alerts. Each entry: (timestamp, tier)
_alert_history: List[Tuple[float, str]] = []

# Flex mode (can be toggled via Telegram /flex command)
_flex_mode = {"enabled": True}

def is_flex_enabled() -> bool:
    return _flex_mode["enabled"]

def set_flex(enabled: bool):
    _flex_mode["enabled"] = enabled

def _prune_history():
    """Keep only last 24h of alert history."""
    cutoff = time.time() - 86400
    while _alert_history and _alert_history[0][0] < cutoff:
        _alert_history.pop(0)

def _count_in_window(seconds: int, tier_filter: Optional[str] = None) -> int:
    cutoff = time.time() - seconds
    return sum(
        1 for ts, tier in _alert_history
        if ts >= cutoff and (tier_filter is None or tier == tier_filter)
    )

def can_send_alert(tier: str, score: int, smart_money_count: int) -> Tuple[bool, str]:
    """Adaptive cap check. Returns (allowed, reason)."""
    _prune_history()

    # ── Strict mode: simple daily cap regardless of tier ──
    if not _flex_mode["enabled"]:
        today_count = _count_in_window(86400)
        if today_count >= config.STRICT_MAX_ALERTS_PER_DAY:
            return False, f"strict daily cap ({config.STRICT_MAX_ALERTS_PER_DAY})"
        return True, "strict mode"

    # ── Exceptional signals bypass ALL caps ──
    is_exceptional = (
        smart_money_count >= config.EXCEPTIONAL_MIN_SMART_WALLETS
        or score >= config.EXCEPTIONAL_MIN_SCORE
    )
    if is_exceptional:
        # Still respect 10-minute burst limit to prevent Telegram from rate-limiting us
        burst = _count_in_window(600)
        if burst >= config.MAX_ALERTS_PER_10MIN + 2:  # +2 grace for exceptional
            return False, f"burst limit (even exceptional) — wait"
        return True, "EXCEPTIONAL bypass"

    # ── Burst limit (10-minute window) ──
    burst = _count_in_window(600)
    if burst >= config.MAX_ALERTS_PER_10MIN:
        return False, f"burst cap ({config.MAX_ALERTS_PER_10MIN}/10min)"

    # ── Hourly limit ──
    hourly = _count_in_window(3600)
    if hourly >= config.MAX_ALERTS_PER_HOUR:
        return False, f"hourly cap ({config.MAX_ALERTS_PER_HOUR}/hr)"

    # ── Tier-specific 24h limits ──
    tier_clean = tier.replace("🎯 ", "").replace("🟢 ", "").replace("👀 ", "").strip()
    daily_tier = _count_in_window(86400, tier_filter=tier_clean)

    if tier_clean == "SNIPER":
        if config.MAX_SNIPER_PER_24H > 0 and daily_tier >= config.MAX_SNIPER_PER_24H:
            return False, f"sniper daily cap ({config.MAX_SNIPER_PER_24H})"
    elif tier_clean == "BUY":
        if daily_tier >= config.MAX_BUY_PER_24H:
            return False, f"BUY tier daily cap ({config.MAX_BUY_PER_24H})"
    elif tier_clean == "WATCH":
        if daily_tier >= config.MAX_WATCH_PER_24H:
            return False, f"WATCH tier daily cap ({config.MAX_WATCH_PER_24H})"

    return True, "ok"

def record_alert(tier: str):
    tier_clean = tier.replace("🎯 ", "").replace("🟢 ", "").replace("👀 ", "").strip()
    _alert_history.append((time.time(), tier_clean))

def get_rate_status() -> Dict[str, Any]:
    """For /status command — show current rate limit state."""
    _prune_history()
    return {
        "flex_enabled": _flex_mode["enabled"],
        "last_10min": _count_in_window(600),
        "last_hour": _count_in_window(3600),
        "last_24h": _count_in_window(86400),
        "sniper_24h": _count_in_window(86400, "SNIPER"),
        "buy_24h": _count_in_window(86400, "BUY"),
        "watch_24h": _count_in_window(86400, "WATCH"),
        "caps": {
            "burst": config.MAX_ALERTS_PER_10MIN,
            "hourly": config.MAX_ALERTS_PER_HOUR,
            "sniper_24h": config.MAX_SNIPER_PER_24H or "∞",
            "buy_24h": config.MAX_BUY_PER_24H,
            "watch_24h": config.MAX_WATCH_PER_24H,
        }
    }

# Per-token cooldown tracking (in-memory)
_last_alerted: Dict[str, float] = {}

def _in_cooldown(token_address: str) -> bool:
    last = _last_alerted.get(token_address)
    if not last: return False
    age_hours = (time.time() - last) / 3600
    return age_hours < config.PER_TOKEN_COOLDOWN_HOURS

def _record_token_cooldown(token_address: str):
    _last_alerted[token_address] = time.time()

# Legacy helpers (kept for backward compatibility with bot.py logging)
def daily_alert_count() -> int:
    _prune_history()
    return _count_in_window(86400)

def daily_cap_reached() -> bool:
    """Soft-check: are we approaching the practical ceiling?"""
    if not _flex_mode["enabled"]:
        return _count_in_window(86400) >= config.STRICT_MAX_ALERTS_PER_DAY
    # In flex mode, "cap reached" means we'd reject any normal signal
    return _count_in_window(3600) >= config.MAX_ALERTS_PER_HOUR

def _in_dead_hours() -> bool:
    if not config.USE_TIME_OF_DAY_FILTER: return False
    h = datetime.now(timezone.utc).hour
    s, e = config.DEAD_HOURS_UTC_START, config.DEAD_HOURS_UTC_END
    if s < e:
        return s <= h < e
    return h >= s or h < e

# ─────────────────────────────────────────
# DEXSCREENER
# ─────────────────────────────────────────
def fetch_latest_profiles() -> List[Dict[str, Any]]:
    data = http_get(config.DEXSCREENER_PROFILES, timeout=15)
    return data if isinstance(data, list) else []

def fetch_pair_data(token_address: str) -> Optional[Dict[str, Any]]:
    data = http_get(config.DEXSCREENER_TOKENS.format(token_address), timeout=10)
    if not data: return None
    pairs = data.get("pairs", []) if isinstance(data, dict) else []
    sol_pairs = [p for p in pairs if p.get("chainId") == "solana"]
    if not sol_pairs: return None
    return max(sol_pairs, key=lambda x: float((x.get("liquidity") or {}).get("usd") or 0))

def get_age_minutes(pair: Dict[str, Any]) -> float:
    try:
        created = pair.get("pairCreatedAt", 0)
        if not created: return 999_999
        now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
        return (now_ms - created) / 60000
    except Exception:
        return 999_999

# ─────────────────────────────────────────
# FILTERS — stricter than v3
# ─────────────────────────────────────────
def passes_filters(pair: Dict[str, Any]) -> Tuple[bool, str]:
    try:
        liq    = float((pair.get("liquidity") or {}).get("usd") or 0)
        vol_1h = float((pair.get("volume") or {}).get("h1") or 0)
        chg_1h = float((pair.get("priceChange") or {}).get("h1") or 0)
        mcap   = float(pair.get("fdv") or 0)
        txns   = (pair.get("txns") or {}).get("h1") or {}
        buys   = int(txns.get("buys") or 0)
        sells  = int(txns.get("sells") or 0)
        total  = buys + sells
        age    = get_age_minutes(pair)

        # Basic gates
        if not (config.MIN_LIQUIDITY <= liq <= config.MAX_LIQUIDITY): return False, f"liq ${liq:,.0f}"
        if vol_1h < config.MIN_VOL_1H: return False, f"vol ${vol_1h:,.0f}"
        if chg_1h < config.MIN_CHANGE_1H: return False, f"chg {chg_1h:.1f}%"
        if not (config.MIN_AGE_MIN <= age <= config.MAX_AGE_MIN): return False, f"age {age:.0f}m"
        if mcap and not (config.MIN_MCAP <= mcap <= config.MAX_MCAP): return False, f"mcap ${mcap:,.0f}"
        if total < config.MIN_TXNS_1H: return False, f"txns {total}"
        if (buys / max(sells, 1)) < config.MIN_BUY_RATIO: return False, f"b/s {buys}/{sells}"

        # ANTI-WASH-TRADE: volume should be a meaningful fraction of liquidity AND average tx size sane
        if liq > 0 and (vol_1h / liq) < config.MIN_VOL_LIQ_RATIO:
            return False, f"low vol/liq {vol_1h/liq:.2f}"
        avg_tx_size = vol_1h / max(total, 1)
        if avg_tx_size > 5000:  # tx size > $5k average smells like dev/whale-only
            return False, f"avg_tx ${avg_tx_size:,.0f}"

        return True, "PASS"
    except Exception as e:
        return False, f"exc: {e}"

# ─────────────────────────────────────────
# SCORING (same model as v3 — already calibrated 0-100)
# ─────────────────────────────────────────
def score_signal(pair: Dict[str, Any]) -> int:
    score = 0
    chg = float((pair.get("priceChange") or {}).get("h1") or 0)
    vol = float((pair.get("volume") or {}).get("h1") or 0)
    liq = float((pair.get("liquidity") or {}).get("usd") or 0)
    txns = (pair.get("txns") or {}).get("h1") or {}
    buys = int(txns.get("buys") or 0); sells = int(txns.get("sells") or 0)

    score += 30 if chg >= 200 else 22 if chg >= 100 else 14 if chg >= 50 else 6
    score += 25 if vol >= 1_000_000 else 18 if vol >= 500_000 else 12 if vol >= 200_000 else 7 if vol >= 100_000 else 0
    score += 20 if 50_000 <= liq <= 200_000 else 12 if 30_000 <= liq < 50_000 else 10 if liq > 200_000 else 0
    ratio = buys / max(sells, 1)
    score += 20 if ratio >= 4 else 14 if ratio >= 2.5 else 8 if ratio >= 1.5 else 3
    age = get_age_minutes(pair)
    score += 5 if 30 <= age <= 90 else 3 if 15 <= age < 30 else 0
    return min(score, 100)

# ─────────────────────────────────────────
# Labels (3-tier Conviction Hierarchy)
# ─────────────────────────────────────────
def label_for(score: int, confirmations: List[str]) -> str:
    """SNIPER = score ≥ 90 AND smart_money OR all 4 layers
       BUY    = score ≥ 80 AND 2+ layers
       WATCH  = passes filters but missing one layer for full BUY
    """
    if score >= config.SNIPER_SCORE and ("smart_money" in confirmations or len(confirmations) >= 4):
        return "🎯 SNIPER"
    if score >= config.MIN_ALERT_SCORE and len(confirmations) >= config.MIN_CONFIRMATION_LAYERS:
        return "🟢 BUY"
    return "👀 WATCH"

# ─────────────────────────────────────────
# BUILD SIGNAL
# ─────────────────────────────────────────
def build_signal(pair: Dict[str, Any], token_address: str) -> Dict[str, Any]:
    base = pair.get("baseToken") or {}
    return {
        "address":   token_address,
        "name":      base.get("name", "Unknown"),
        "symbol":    base.get("symbol", "???"),
        "price":     float(pair.get("priceUsd") or 0),
        "change_1h": float((pair.get("priceChange") or {}).get("h1") or 0),
        "liquidity": float((pair.get("liquidity") or {}).get("usd") or 0),
        "volume_1h": float((pair.get("volume") or {}).get("h1") or 0),
        "mcap":      float(pair.get("fdv") or 0),
        "age_min":   round(get_age_minutes(pair), 1),
        "dex_url":   pair.get("url", ""),
    }

# ─────────────────────────────────────────
# EVALUATION PIPELINE
# ─────────────────────────────────────────
def evaluate_token(token_address: str) -> Optional[Dict[str, Any]]:
    """Returns a signal dict ONLY if it passes every Conviction Mode gate
    AND the Adaptive Cap allows another alert in the current rate window.
    Returns None otherwise.
    """
    # Stage 0: per-token cooldown
    if _in_cooldown(token_address):
        return None

    # Stage 1: market filters
    pair = fetch_pair_data(token_address)
    if not pair:
        return None
    ok, reason = passes_filters(pair)
    if not ok:
        return None

    signal = build_signal(pair, token_address)
    signal["score"] = score_signal(pair)

    # Stage 2: assemble confirmation layers
    confirmations = ["filters_passed"]

    # — smart money
    sm = smart_money.smart_money_for_token(token_address)
    signal["smart_money"] = sm
    if sm.get("count", 0) >= config.SMART_MONEY_BOOST_THRESHOLD:
        confirmations.append("smart_money")

    # — velocity
    v = trending.get_velocity(token_address)
    signal["velocity"] = v
    if v and v.get("rank_change", 0) >= config.VELOCITY_CONFIRMATION_RANK_CHANGE:
        confirmations.append("velocity")

    # — momentum
    if signal["score"] >= 85:
        confirmations.append("momentum")

    # — social (only check if we might already qualify, saves API calls)
    if config.USE_SOCIAL_CHECK and len(confirmations) >= 1:
        try:
            s = social.get_social_score(signal["symbol"], token_address)
            signal["social"] = s
            if s.get("mentions_estimate", 0) >= config.SOCIAL_CONFIRMATION_THRESHOLD:
                confirmations.append("social")
        except Exception:
            signal["social"] = {}

    signal["confirmations"] = confirmations

    # Stage 3: time-of-day score floor
    score_floor = config.DEAD_HOURS_MIN_SCORE if _in_dead_hours() else config.MIN_ALERT_SCORE
    smart_money_present = "smart_money" in confirmations
    # Smart money confirmation can bypass the dead-hours floor
    if signal["score"] < score_floor and not smart_money_present:
        return None

    # Stage 4: confirmation layer requirement
    # Smart money alone counts as 2 layers (it's that strong a signal)
    effective_layers = len(confirmations) + (1 if smart_money_present else 0)
    if effective_layers < config.MIN_CONFIRMATION_LAYERS:
        return None

    # Stage 5: rug check — must pass
    rug = comprehensive_rug_check(token_address)
    signal["rug_check"] = rug
    if not rug["safe"]:
        log.info(f"  🛡 Rug-filtered: {signal['symbol']} — {', '.join(rug['fails'][:2])}")
        return None

    # Stage 6: assign label tier
    signal["label"] = label_for(signal["score"], confirmations)

    # Stage 7: Adaptive rate limiter
    allowed, why = can_send_alert(
        signal["label"],
        signal["score"],
        sm.get("count", 0)
    )
    if not allowed:
        log.info(f"  ⏸ Throttled {signal['symbol']} ({signal['label']}): {why}")
        return None

    # Mark this token + record rate-limit entry
    _record_token_cooldown(token_address)
    record_alert(signal["label"])
    return signal
