"""Telegram — Conviction Mode alerts.
Three alert tiers: 🎯 SNIPER, 🟢 BUY, 👀 WATCH.
SNIPER tier also broadcasts to optional public channel (if configured).
"""
import time
import logging
import requests
from typing import Optional

import config
import db
import smart_money
import outcome_tracker
import social as social_mod
import trending
import scanner
import self_tuner

log = logging.getLogger("SolSniper")

_BASE = lambda: f"https://api.telegram.org/bot{config.TELEGRAM_TOKEN}"

def enabled() -> bool:
    return bool(config.TELEGRAM_TOKEN and config.TELEGRAM_CHAT_ID)

def send(text: str, parse_mode: str = "Markdown", target_chat: Optional[str] = None) -> bool:
    if not config.TELEGRAM_TOKEN: return False
    chat = target_chat or config.TELEGRAM_CHAT_ID
    if not chat: return False
    try:
        r = requests.post(
            f"{_BASE()}/sendMessage",
            json={
                "chat_id": chat,
                "text": text[:4000],
                "parse_mode": parse_mode,
                "disable_web_page_preview": True,
            },
            timeout=10,
        )
        return r.status_code == 200
    except Exception as e:
        log.error(f"Telegram send error: {e}")
        return False

def format_signal(s: dict) -> str:
    sm = s.get("smart_money", {})
    rug = s.get("rug_check", {})
    velocity = s.get("velocity")
    social = s.get("social", {})
    confs = s.get("confirmations", [])

    label = s["label"]
    header = f"*{label}* — {s['name']} ({s['symbol']})"

    lines = [header, ""]
    # Confirmation badges
    badges = []
    if "smart_money" in confs: badges.append(f"🐋 SmartMoney×{sm.get('count',0)}")
    if "velocity" in confs: badges.append("📈 Trending")
    if "momentum" in confs: badges.append("⚡ Momentum")
    if "social" in confs: badges.append("💬 Social")
    if badges:
        lines.append("Confirmations: " + " · ".join(badges))
        lines.append("")

    # Smart money detail
    if sm.get("count", 0) > 0:
        wallets_str = ", ".join(sm["wallets"][:3])
        lines.append(f"🐋 {sm['count']} smart wallets bought in last {sm.get('oldest_min', '?')}min")
        lines.append(f"   ↳ {wallets_str} | total: {sm['total_sol']} SOL")
        lines.append("")

    # Score + rug
    risk = rug.get("risk_level", "?")
    risk_emoji = "🟢" if risk == "LOW" else "🟡" if risk == "MEDIUM" else "🔴"
    lines.append(f"💯 Score: *{s['score']}/100* | 🛡 Risk: {risk_emoji} {risk}")
    for line in rug.get("summary_lines", [])[:4]:
        lines.append(f"   • {line}")

    # Market data
    lines.append("")
    lines.append(f"📊 1h: *+{s['change_1h']:.1f}%* | 💧 ${s['liquidity']:,.0f} | 📈 ${s['volume_1h']:,.0f}/1h")
    lines.append(f"💰 MCap ${s['mcap']:,.0f} | ⏱ {s['age_min']:.0f}min | 💵 ${s['price']:.8f}")

    v_line = trending.format_velocity_line(velocity) if velocity else None
    if v_line: lines.append(v_line)
    s_line = social_mod.format_social_line(social) if social else None
    if s_line: lines.append(s_line)

    lines.append("")
    lines.append(f"`{s['address']}`")
    lines.append(
        f"[Chart]({s.get('dex_url','')}) · "
        f"[RugCheck](https://rugcheck.xyz/tokens/{s['address']}) · "
        f"[Solscan](https://solscan.io/token/{s['address']})"
    )
    return "\n".join(lines)

def broadcast_if_sniper(signal: dict):
    """Also post SNIPER-tier signals to a public channel if configured."""
    if "SNIPER" in signal.get("label", "") and config.BROADCAST_CHANNEL_ID:
        # Strip private info for public broadcast (remove wallet labels)
        public_msg = format_signal(signal)
        # Replace specific wallet labels with generic count
        sm = signal.get("smart_money", {})
        if sm.get("count", 0) > 0 and sm.get("wallets"):
            public_msg = public_msg.replace(
                f"   ↳ {', '.join(sm['wallets'][:3])} | total:",
                f"   ↳ {sm['count']} known profitable wallets | total:"
            )
        send(public_msg, target_chat=config.BROADCAST_CHANNEL_ID)

# ─────────────────────────────────────────
# COMMANDS
# ─────────────────────────────────────────
def _handle_command(text: str, state: dict):
    parts = text.strip().split()
    cmd = parts[0].lower() if parts else ""

    if cmd == "/status":
        s = db.get_summary_stats()
        wallets = smart_money.load_wallets()
        rate = scanner.get_rate_status()
        flex_str = "🌊 FLEX ON" if rate["flex_enabled"] else "🔒 STRICT"
        send(
            f"📊 *Conviction Mode — Status*\n\n"
            f"State: {'⏸ PAUSED' if state.get('paused') else '▶️ RUNNING'}\n"
            f"Rate mode: *{flex_str}*\n\n"
            f"*Activity:*\n"
            f"  • Last 10min: {rate['last_10min']}/{rate['caps']['burst']}\n"
            f"  • Last 1hr: {rate['last_hour']}/{rate['caps']['hourly']}\n"
            f"  • Last 24h: {rate['last_24h']}\n\n"
            f"*By tier (24h):*\n"
            f"  • 🎯 SNIPER: {rate['sniper_24h']}/{rate['caps']['sniper_24h']}\n"
            f"  • 🟢 BUY: {rate['buy_24h']}/{rate['caps']['buy_24h']}\n"
            f"  • 👀 WATCH: {rate['watch_24h']}/{rate['caps']['watch_24h']}\n\n"
            f"Scans: {s['scans']} | Alerts lifetime: {s['signals']}\n"
            f"🐋 Smart money alerts: {s['smart_money_signals']}\n"
            f"Wallets tracked: {len(wallets)}\n"
            f"Last scan: {s['last_scan']}"
        )

    elif cmd == "/flex":
        if len(parts) < 2:
            cur = "ON" if scanner.is_flex_enabled() else "OFF"
            send(f"🌊 Flex mode currently *{cur}*\n\nUsage: `/flex on` or `/flex off`")
            return
        val = parts[1].lower()
        if val in ("on", "true", "1", "enable"):
            scanner.set_flex(True)
            send("🌊 *Flex mode ON*\n\nAdaptive caps active. SNIPER tier never throttled. "
                 "Burst protection: 3/10min, 8/hr. Per-tier 24h caps apply.")
        elif val in ("off", "false", "0", "disable"):
            scanner.set_flex(False)
            send(f"🔒 *Strict mode ON*\n\nHard limit: {config.STRICT_MAX_ALERTS_PER_DAY} alerts/day, all tiers combined.")
        else:
            send("Usage: `/flex on` or `/flex off`")

    elif cmd == "/recent":
        sigs = db.recent_signals(10)
        if not sigs: send("No signals yet."); return
        lines = ["📡 *Recent 10 alerts*\n"]
        for sig in sigs:
            t = (sig["created_at"] or "")[11:16]
            sm_tag = f" 🐋×{sig['smart_money_count']}" if sig['smart_money_count'] > 0 else ""
            lines.append(f"`{t}` *{sig['symbol']}* {sig['label']}{sm_tag} (s{sig['score']} +{sig['change_1h']:.0f}%)")
        send("\n".join(lines))

    elif cmd == "/smartmoney":
        top = smart_money.top_recent_tokens(min_wallets=1, top_n=10)
        if not top: send("🐋 No smart money activity in last 15min."); return
        lines = ["🐋 *Smart Money — Top buys (last 15 min)*\n"]
        for t in top:
            lines.append(f"`{t['mint'][:8]}...` — *{t['wallet_count']}* wallets, "
                         f"{t['total_sol']:.2f} SOL ({t['oldest_min']:.0f}m ago)")
        send("\n".join(lines))

    elif cmd == "/discover":
        send("🧠 Running smart-money discovery pass now… (this can take a few minutes)")
        try:
            import wallet_discovery
            n = wallet_discovery.run_discovery_pass()
            if n > 0:
                send(f"✅ Discovery done. Promoted {n} new wallet(s). Total tracked: {len(smart_money.load_wallets())}.")
            else:
                send("ℹ️ Discovery done. No new wallets promoted yet. "
                     "This needs winning signals first (tokens that pumped after we alerted). "
                     "It improves automatically as the bot runs.")
        except Exception as e:
            send(f"⚠️ Discovery error: `{str(e)[:150]}`")

    elif cmd == "/addwallet":
        if len(parts) < 2: send("Usage: `/addwallet <address> [label]`"); return
        addr = parts[1]
        label = parts[2] if len(parts) > 2 else "manual"
        if len(addr) < 32: send("❌ Invalid Solana address"); return
        if smart_money.add_wallet(addr, label):
            send(f"✅ Added `{addr[:8]}...` as `{label}`")
        else:
            send("⚠️ Already tracked")

    elif cmd == "/removewallet":
        if len(parts) < 2: send("Usage: `/removewallet <address>`"); return
        if smart_money.remove_wallet(parts[1]):
            send(f"✅ Removed `{parts[1][:8]}...`")
        else:
            send("❌ Not found")

    elif cmd == "/wallets":
        wallets = smart_money.load_wallets()
        if not wallets:
            send("📭 No wallets tracked. Add some with `/addwallet <address> <label>`"); return
        lines = [f"🐋 *Tracking {len(wallets)} wallets*\n"]
        for w in wallets[:20]:
            lines.append(f"`{w[0][:8]}...` — {w[1] if len(w) > 1 else '?'}")
        if len(wallets) > 20:
            lines.append(f"... and {len(wallets) - 20} more")
        send("\n".join(lines))

    elif cmd == "/performance":
        perf = outcome_tracker.get_performance_stats()
        if perf["total_tracked"] == 0:
            send("📊 No data yet. Need 1h+ of alerts for stats.")
            return
        lines = [
            f"📈 *Performance ({perf['total_tracked']} tracked signals)*\n",
            f"Win rate @ 1h: *{perf['win_rate_1h']}%*",
            f"Avg PnL @ 1h: *{perf['avg_pnl_1h']:+.1f}%*",
            f"Avg peak PnL: *{perf['avg_peak_pnl']:+.1f}%*",
        ]
        if perf.get("win_rate_24h") is not None:
            lines.append(f"Win rate @ 24h: *{perf['win_rate_24h']}%*")
        send("\n".join(lines))

    elif cmd == "/tuning":
        analysis = self_tuner.analyze_outcomes()
        if not analysis:
            send(f"🧠 Not enough data. Need {config.SELF_TUNE_AFTER_N_OUTCOMES}+ tracked outcomes.")
            return
        send(self_tuner.format_tuning_report(analysis))

    elif cmd == "/pause":
        state["paused"] = True
        send("⏸ Bot paused.")
    elif cmd == "/resume":
        state["paused"] = False
        send("▶️ Bot resumed.")

    elif cmd in ("/start", "/help"):
        send(
            "🤖 *SolSniper Conviction Mode (Adaptive Cap)*\n\n"
            "Quality-first alerts. Adaptive throttling that *never caps exceptional signals*.\n\n"
            "*Tiers:*\n"
            "🎯 SNIPER — score ≥90 + smart money or 4 layers (uncapped)\n"
            "🟢 BUY — score ≥80 + 2 confirmation layers\n"
            "👀 WATCH — interesting but missing a layer\n\n"
            "*Adaptive Cap rules:*\n"
            "• Burst: 3 alerts per 10min (anti-spam)\n"
            "• Hourly: 8 alerts per hour\n"
            "• 24h SNIPER: unlimited\n"
            "• 24h BUY: 12 max\n"
            "• 24h WATCH: 4 max\n"
            "• Exceptional bypass: 4+ smart wallets OR score ≥95 fires anyway\n\n"
            "*Core:*\n"
            "/status — bot state + rate limit status\n"
            "/recent — last 10 alerts\n"
            "/performance — win-rate analytics\n"
            "/tuning — self-tuning analysis\n"
            "/flex on|off — toggle adaptive vs strict cap\n"
            "/pause /resume — control alerts\n\n"
            "*Smart Money:*\n"
            "/smartmoney — top tokens smart wallets buying now\n"
            "/wallets — list tracked wallets\n"
            "/addwallet <addr> [label]\n"
            "/removewallet <addr>"
        )

def listen(state: dict):
    if not enabled():
        log.info("Telegram disabled"); return

    last_update = 0
    try:
        r = requests.get(f"{_BASE()}/getUpdates", timeout=10).json()
        if r.get("result"):
            last_update = r["result"][-1]["update_id"]
    except Exception: pass

    send("🤖 SolSniper *Conviction Mode* online. Quality over quantity. /help for commands.")

    while state.get("running", True):
        try:
            r = requests.get(
                f"{_BASE()}/getUpdates",
                params={"offset": last_update + 1, "timeout": 25},
                timeout=30,
            ).json()
            for upd in r.get("result", []):
                last_update = upd["update_id"]
                msg = upd.get("message") or upd.get("channel_post") or {}
                chat_id = str(msg.get("chat", {}).get("id", ""))
                if chat_id != str(config.TELEGRAM_CHAT_ID): continue
                txt = msg.get("text", "")
                if txt: _handle_command(txt, state)
        except Exception as e:
            log.debug(f"Telegram poll error: {e}")
            time.sleep(5)
