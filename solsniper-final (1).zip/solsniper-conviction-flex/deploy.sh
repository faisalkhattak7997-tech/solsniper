#!/usr/bin/env bash
# SolSniper v2 deployment — Ubuntu 22.04 / 24.04
set -euo pipefail

USER_NAME="solsniper"
APP_DIR="/opt/solsniper"
PYTHON="python3.11"

echo "═══════════════════════════════════════════════════════════"
echo "  SolSniper v2 (alerts-only) Deployment"
echo "═══════════════════════════════════════════════════════════"

if [[ $EUID -ne 0 ]]; then
   echo "Run as root: sudo bash deploy.sh" >&2; exit 1
fi

echo ">> Updating system"
apt-get update -qq
apt-get install -y -qq software-properties-common curl ufw fail2ban git
add-apt-repository -y ppa:deadsnakes/ppa
apt-get update -qq
apt-get install -y -qq $PYTHON ${PYTHON}-venv ${PYTHON}-dev build-essential

if ! id "$USER_NAME" &>/dev/null; then
    echo ">> Creating user $USER_NAME"
    useradd -m -s /bin/bash "$USER_NAME"
fi

echo ">> Installing to $APP_DIR"
mkdir -p "$APP_DIR"
cp -r ./* "$APP_DIR/"
chown -R "$USER_NAME:$USER_NAME" "$APP_DIR"
chmod 700 "$APP_DIR"

if [[ ! -f "$APP_DIR/.env" ]]; then
    cp "$APP_DIR/.env.example" "$APP_DIR/.env"
    chmod 600 "$APP_DIR/.env"
    chown "$USER_NAME:$USER_NAME" "$APP_DIR/.env"
    echo ">> ⚠️  Created $APP_DIR/.env from template — EDIT before starting"
fi

echo ">> Python venv"
sudo -u "$USER_NAME" $PYTHON -m venv "$APP_DIR/venv"
sudo -u "$USER_NAME" "$APP_DIR/venv/bin/pip" install --quiet --upgrade pip
sudo -u "$USER_NAME" "$APP_DIR/venv/bin/pip" install --quiet -r "$APP_DIR/requirements.txt"

mkdir -p "$APP_DIR/data" "$APP_DIR/logs"
chown -R "$USER_NAME:$USER_NAME" "$APP_DIR/data" "$APP_DIR/logs"

# systemd: bot
cat > /etc/systemd/system/solsniper.service <<EOF
[Unit]
Description=SolSniper v2 Alert Bot
After=network.target

[Service]
Type=simple
User=$USER_NAME
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/venv/bin/python $APP_DIR/bot.py
Restart=always
RestartSec=10
StandardOutput=append:$APP_DIR/logs/bot.stdout.log
StandardError=append:$APP_DIR/logs/bot.stderr.log
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=$APP_DIR/data $APP_DIR/logs
ProtectHome=true

[Install]
WantedBy=multi-user.target
EOF

# systemd: dashboard
cat > /etc/systemd/system/solsniper-dashboard.service <<EOF
[Unit]
Description=SolSniper v2 Dashboard
After=network.target

[Service]
Type=simple
User=$USER_NAME
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/venv/bin/python $APP_DIR/dashboard.py
Restart=always
RestartSec=10
StandardOutput=append:$APP_DIR/logs/dashboard.log
StandardError=append:$APP_DIR/logs/dashboard.log
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF

# Daily auto-restart for cleanliness (4am UTC)
cat > /etc/systemd/system/solsniper-daily-restart.service <<EOF
[Unit]
Description=Daily SolSniper restart for cleanliness
[Service]
Type=oneshot
ExecStart=/bin/systemctl restart solsniper
EOF
cat > /etc/systemd/system/solsniper-daily-restart.timer <<EOF
[Unit]
Description=Restart SolSniper daily at 04:00 UTC
[Timer]
OnCalendar=*-*-* 04:00:00
Persistent=true
[Install]
WantedBy=timers.target
EOF

# logrotate
cat > /etc/logrotate.d/solsniper <<EOF
$APP_DIR/logs/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    su $USER_NAME $USER_NAME
}
EOF

# UFW firewall
echo ">> Configuring firewall"
ufw --force reset >/dev/null
ufw default deny incoming >/dev/null
ufw default allow outgoing >/dev/null
ufw allow 22/tcp comment 'SSH' >/dev/null
ufw allow 8080/tcp comment 'Dashboard' >/dev/null
ufw --force enable >/dev/null

systemctl enable --now fail2ban >/dev/null
systemctl daemon-reload
systemctl enable solsniper.service solsniper-dashboard.service solsniper-daily-restart.timer >/dev/null

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  ✅ Installation complete"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "  Next steps:"
echo "    1. Edit .env:           sudo nano $APP_DIR/.env"
echo "    2. Start the bot:       sudo systemctl start solsniper"
echo "    3. Start dashboard:     sudo systemctl start solsniper-dashboard"
echo "    4. Enable daily restart: sudo systemctl start solsniper-daily-restart.timer"
echo "    5. Tail logs:           sudo journalctl -u solsniper -f"
echo "    6. Open dashboard:      http://YOUR_VPS_IP:8080/?token=YOUR_DASHBOARD_TOKEN"
echo ""
