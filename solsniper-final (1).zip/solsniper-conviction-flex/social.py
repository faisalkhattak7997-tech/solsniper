"""Social signal correlation — Twitter/X cashtag check.

Free approach: scrape Nitter / use public-search endpoints.
For real production, you'd need X API access ($100+/mo) but for v3 we use
the lightweight approach of just checking if a symbol is being mentioned at all.

This is a SOFT signal — adds context but never gates an alert.
"""
import logging
import requests
from typing import Optional, Dict
from http_utils import http_get

log = logging.getLogger("SolSniper")

# Public Nitter instances (rotate if any go down)
NITTER_INSTANCES = [
    "https://nitter.net",
    "https://nitter.privacydev.net",
    "https://nitter.poast.org",
]

def get_social_score(symbol: str, token_address: str) -> Dict:
    """Returns {mentions_estimate, hot, source} or empty dict on failure.
    Note: This is a best-effort soft signal. We don't gate on it.
    """
    result = {"mentions_estimate": 0, "hot": False, "source": ""}

    # Strategy 1: Try Nitter search (free)
    for instance in NITTER_INSTANCES:
        try:
            r = requests.get(
                f"{instance}/search",
                params={"f": "tweets", "q": f"${symbol}", "since": "today"},
                timeout=6,
                headers={"User-Agent": "Mozilla/5.0"},
            )
            if r.status_code == 200 and len(r.text) > 1000:
                # Rough heuristic: count tweet timestamps in HTML
                count = r.text.count("tweet-date")
                result["mentions_estimate"] = count
                result["hot"] = count >= 10
                result["source"] = "nitter"
                return result
        except requests.RequestException:
            continue

    return result

def format_social_line(social: Dict) -> Optional[str]:
    """Generate a one-line summary for the Telegram alert. None if no data."""
    if not social or social.get("mentions_estimate", 0) == 0:
        return None
    n = social["mentions_estimate"]
    if n >= 30:
        return f"🔥 *Trending on X* — {n}+ mentions today"
    elif n >= 10:
        return f"💬 Social buzz — ~{n} X mentions today"
    elif n >= 3:
        return f"💬 ~{n} X mentions"
    return None
