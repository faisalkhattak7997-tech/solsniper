"""Trending velocity tracker.

Tracks each token's rank in DexScreener's latest profiles list over time.
A token jumping from rank #45 to rank #3 in 2 hours is more interesting
than absolute price change alone.
"""
import time
import logging
from collections import defaultdict
from typing import Dict, List, Optional

log = logging.getLogger("SolSniper")

# token_address → list of (timestamp, rank)
_rank_history: Dict[str, list] = defaultdict(list)

def record_ranks(profiles: List[Dict]):
    """Call this every scan with the latest DexScreener profiles list."""
    now = time.time()
    for i, p in enumerate(profiles):
        addr = p.get("tokenAddress", "")
        if not addr or p.get("chainId") != "solana": continue
        _rank_history[addr].append((now, i + 1))
        # Keep only last 4 hours
        cutoff = now - 14400
        _rank_history[addr] = [r for r in _rank_history[addr] if r[0] >= cutoff]
    # Prune tokens not seen in this scan
    seen = {p.get("tokenAddress") for p in profiles}
    for addr in list(_rank_history.keys()):
        if addr not in seen:
            # Don't delete yet; if it disappeared but had recent history, keep briefly
            if not _rank_history[addr] or _rank_history[addr][-1][0] < now - 600:
                del _rank_history[addr]

def get_velocity(token_address: str) -> Optional[Dict]:
    """Returns rank velocity info, or None if insufficient data."""
    h = _rank_history.get(token_address, [])
    if len(h) < 2:
        return None
    earliest = h[0]
    latest = h[-1]
    rank_change = earliest[1] - latest[1]  # positive = climbed
    time_span_min = (latest[0] - earliest[0]) / 60
    if time_span_min < 5:
        return None
    return {
        "earliest_rank": earliest[1],
        "current_rank": latest[1],
        "rank_change": rank_change,
        "time_span_min": round(time_span_min, 1),
        "rising_fast": rank_change >= 20 and time_span_min <= 60,
    }

def format_velocity_line(v: Dict) -> Optional[str]:
    if not v: return None
    if v["rising_fast"]:
        return f"📈 Trending: jumped #{v['earliest_rank']} → #{v['current_rank']} in {v['time_span_min']:.0f}min"
    if v["rank_change"] >= 10:
        return f"📈 Trending: climbed {v['rank_change']} ranks"
    return None
