"""Smart Money Tracker.

Watches a curated list of profitable Solana wallets. When 2+ tracked wallets
buy the same token within a short window, that's a high-conviction signal.

Strategy:
  - Poll each wallet's recent signatures via getSignaturesForAddress (cheap)
  - Parse transactions to detect token purchases
  - Cross-reference: did multiple smart wallets buy the same token recently?
  - Surface this as a boost on existing signals or standalone alert

Free-tier RPC math (Helius 10 RPS):
  - 150 wallets × 1 poll/60s = 2.5 RPS — well within budget
  - We use a 60-90s polling cadence per wallet (longer for less-active ones)
"""
import os
import time
import json
import logging
import threading
import requests
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Set, Optional, Tuple
from collections import defaultdict

import config
import db
from http_utils import http_post

log = logging.getLogger("SolSniper")

# ─────────────────────────────────────────
# Curated wallet list
# Stored in data/smart_wallets.json so user can edit it on the VPS.
# We ship a starter list of 30 wallets known to GMGN's leaderboard
# (these are PUBLIC addresses, not secret) — user can add more via /addwallet
# ─────────────────────────────────────────
STARTER_WALLETS = [
    # Format: ["address", "label", "trust_score 1-10"]
    # These are placeholder example addresses — the README explains how to
    # source the real list from GMGN, Solscan PnL rankings, etc.
    # NOTE: A real list would be hand-curated. We ship empty by default
    # to avoid stale references; user populates via /addwallet command.
]

WALLETS_FILE = os.path.join(os.path.dirname(config.DB_PATH), "smart_wallets.json")

def load_wallets() -> List[Dict]:
    if not os.path.exists(WALLETS_FILE):
        save_wallets(STARTER_WALLETS)
        return list(STARTER_WALLETS)
    try:
        with open(WALLETS_FILE) as f:
            data = json.load(f)
        return [w for w in data if isinstance(w, list) and len(w) >= 2]
    except Exception as e:
        log.error(f"smart_wallets load error: {e}")
        return []

def save_wallets(wallets: List[Dict]):
    os.makedirs(os.path.dirname(WALLETS_FILE), exist_ok=True)
    with open(WALLETS_FILE, "w") as f:
        json.dump(wallets, f, indent=2)

def add_wallet(address: str, label: str = "manual", trust: int = 5) -> bool:
    wallets = load_wallets()
    if any(w[0] == address for w in wallets):
        return False
    wallets.append([address, label, trust])
    save_wallets(wallets)
    return True

def remove_wallet(address: str) -> bool:
    wallets = load_wallets()
    before = len(wallets)
    wallets = [w for w in wallets if w[0] != address]
    if len(wallets) < before:
        save_wallets(wallets)
        return True
    return False

# ─────────────────────────────────────────
# Recent buys tracking
# Maps: token_address → list of (wallet_address, timestamp, amount_sol)
# Pruned to last 30 minutes.
# ─────────────────────────────────────────
_recent_buys: Dict[str, List[Tuple[str, float, float]]] = defaultdict(list)
_last_sigs: Dict[str, str] = {}  # wallet → last seen tx signature
_lock = threading.Lock()

CONFIRMATION_WINDOW_MIN = 15  # if 2+ wallets buy within this many minutes = signal
PRUNE_OLDER_THAN_MIN = 30

# ─────────────────────────────────────────
# RPC helpers
# ─────────────────────────────────────────
def get_recent_signatures(wallet: str, before: Optional[str] = None,
                          limit: int = 10) -> List[Dict]:
    """Fetch most recent signatures for a wallet."""
    params = [wallet, {"limit": limit}]
    if before:
        params[1]["before"] = before
    r = http_post(config.SOLANA_RPC, json_body={
        "jsonrpc": "2.0", "id": 1,
        "method": "getSignaturesForAddress",
        "params": params,
    }, timeout=10, retries=2)
    if not r:
        return []
    return r.get("result", []) or []

def get_transaction(signature: str) -> Optional[Dict]:
    """Fetch parsed transaction."""
    r = http_post(config.SOLANA_RPC, json_body={
        "jsonrpc": "2.0", "id": 1,
        "method": "getTransaction",
        "params": [signature, {
            "encoding": "jsonParsed",
            "maxSupportedTransactionVersion": 0,
        }],
    }, timeout=10, retries=1)
    if not r:
        return None
    return r.get("result")

def parse_token_buys(tx: Dict, wallet: str) -> List[Tuple[str, float]]:
    """Given a parsed transaction, return list of (token_mint, sol_spent) for buys.
    A "buy" = wallet's SOL balance decreased AND a non-SOL token balance increased.
    """
    if not tx or tx.get("meta", {}).get("err"):
        return []
    buys = []
    try:
        meta = tx["meta"]
        message = tx["transaction"]["message"]
        account_keys = [
            (k["pubkey"] if isinstance(k, dict) else k)
            for k in message["accountKeys"]
        ]

        # Find wallet index
        if wallet not in account_keys:
            return []
        widx = account_keys.index(wallet)

        # SOL balance change for this wallet (negative = spent)
        pre_sol = meta["preBalances"][widx] / 1e9
        post_sol = meta["postBalances"][widx] / 1e9
        sol_delta = post_sol - pre_sol
        # Account for tx fee (paid by fee payer = usually wallet)
        fee = meta.get("fee", 0) / 1e9

        if sol_delta >= -0.001:  # Didn't spend meaningful SOL
            return []
        sol_spent = abs(sol_delta) - fee
        if sol_spent < 0.005:  # Filter dust
            return []

        # Token balance increases for this wallet
        pre_tokens = {tb["mint"]: float(tb["uiTokenAmount"]["uiAmount"] or 0)
                      for tb in meta.get("preTokenBalances", [])
                      if tb.get("owner") == wallet}
        post_tokens = {tb["mint"]: float(tb["uiTokenAmount"]["uiAmount"] or 0)
                       for tb in meta.get("postTokenBalances", [])
                       if tb.get("owner") == wallet}

        all_mints = set(pre_tokens.keys()) | set(post_tokens.keys())
        for mint in all_mints:
            if mint == config.SOL_MINT if hasattr(config, "SOL_MINT") else "So11111111111111111111111111111111111111112":
                continue
            increase = post_tokens.get(mint, 0) - pre_tokens.get(mint, 0)
            if increase > 0:
                buys.append((mint, sol_spent))
                break  # one main token per tx
    except Exception as e:
        log.debug(f"parse tx error: {e}")
    return buys

# ─────────────────────────────────────────
# Polling worker
# ─────────────────────────────────────────
def poll_wallet(wallet_entry: List) -> int:
    """Poll one wallet. Returns number of new buys recorded."""
    wallet = wallet_entry[0]
    label = wallet_entry[1] if len(wallet_entry) > 1 else "unknown"

    last_sig = _last_sigs.get(wallet)
    sigs = get_recent_signatures(wallet, before=None, limit=5)
    if not sigs:
        return 0

    # Filter to new ones only
    new_sigs = []
    for s in sigs:
        sig = s.get("signature")
        if sig == last_sig:
            break
        if s.get("err"):
            continue
        new_sigs.append(sig)
    if not new_sigs:
        return 0

    _last_sigs[wallet] = sigs[0]["signature"]

    # First run: just initialize, don't process old txs
    if last_sig is None:
        return 0

    # Process new txs
    count = 0
    for sig in new_sigs[:3]:  # cap to avoid blowing rate limit
        tx = get_transaction(sig)
        if not tx: continue
        buys = parse_token_buys(tx, wallet)
        now_ts = time.time()
        with _lock:
            for mint, sol_spent in buys:
                _recent_buys[mint].append((wallet, now_ts, sol_spent))
                log.info(f"🐋 Smart wallet {label} bought {mint[:8]}... for {sol_spent:.3f} SOL")
                count += 1
        time.sleep(0.3)  # rate-limit-friendly
    return count

def prune_old_buys():
    cutoff = time.time() - (PRUNE_OLDER_THAN_MIN * 60)
    with _lock:
        for mint in list(_recent_buys.keys()):
            _recent_buys[mint] = [b for b in _recent_buys[mint] if b[1] >= cutoff]
            if not _recent_buys[mint]:
                del _recent_buys[mint]

def smart_money_for_token(token_address: str) -> Dict:
    """How many smart wallets bought this token in the recent window?
    Returns: {count, wallets: [label], total_sol, recent: bool}"""
    cutoff = time.time() - (CONFIRMATION_WINDOW_MIN * 60)
    with _lock:
        buys = [b for b in _recent_buys.get(token_address, []) if b[1] >= cutoff]
    if not buys:
        return {"count": 0, "wallets": [], "total_sol": 0, "recent": False}

    # Lookup labels
    wallets_meta = {w[0]: (w[1] if len(w) > 1 else "wallet") for w in load_wallets()}
    labels = list(set(wallets_meta.get(b[0], b[0][:8]) for b in buys))
    return {
        "count": len(set(b[0] for b in buys)),  # unique wallets
        "wallets": labels[:5],
        "total_sol": round(sum(b[2] for b in buys), 3),
        "recent": True,
        "oldest_min": round((time.time() - min(b[1] for b in buys)) / 60, 1),
    }

# ─────────────────────────────────────────
# Polling loop (runs in own thread)
# ─────────────────────────────────────────
def polling_loop(state: Dict):
    log.info("Smart money tracker started")
    wallet_index = 0
    while state.get("running", True):
        try:
            wallets = load_wallets()
            if not wallets:
                time.sleep(60); continue

            # Round-robin: poll one wallet per cycle, ~2-3s per cycle
            # → full cycle through 150 wallets every 5 min
            entry = wallets[wallet_index % len(wallets)]
            wallet_index += 1
            poll_wallet(entry)

            # Every 50 polls, prune old buys
            if wallet_index % 50 == 0:
                prune_old_buys()

            time.sleep(2)  # gentle on RPC: 0.5 RPS
        except Exception as e:
            log.exception(f"Smart money poll error: {e}")
            time.sleep(5)

# ─────────────────────────────────────────
# Top-discovered tokens (for /smartmoney command)
# ─────────────────────────────────────────
def top_recent_tokens(min_wallets: int = 1, top_n: int = 10) -> List[Dict]:
    """Tokens most actively bought by smart money in recent window."""
    cutoff = time.time() - (CONFIRMATION_WINDOW_MIN * 60)
    results = []
    with _lock:
        for mint, buys in _recent_buys.items():
            recent = [b for b in buys if b[1] >= cutoff]
            unique_wallets = set(b[0] for b in recent)
            if len(unique_wallets) >= min_wallets:
                results.append({
                    "mint": mint,
                    "wallet_count": len(unique_wallets),
                    "total_sol": sum(b[2] for b in recent),
                    "oldest_min": round((time.time() - min(b[1] for b in recent)) / 60, 1),
                })
    results.sort(key=lambda x: (x["wallet_count"], x["total_sol"]), reverse=True)
    return results[:top_n]
