"""SolSniper v3 dashboard."""
import os
import json
import logging
from flask import Flask, jsonify, request, render_template_string, abort

import config
import db
import smart_money
import outcome_tracker

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("Dashboard")
app = Flask(__name__)

def require_auth():
    if not config.DASHBOARD_TOKEN:
        abort(503, "Dashboard disabled")
    token = request.args.get("token") or request.headers.get("X-Auth-Token", "")
    if token != config.DASHBOARD_TOKEN:
        abort(401, "Invalid token")

INDEX_HTML = """<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<title>SolSniper · Dashboard</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
:root{
  --bg:#0b0f1a; --bg2:#121826; --card:#161d2e; --card2:#1b2336;
  --border:#26304a; --text:#e6edf6; --muted:#8b97ad; --dim:#5c6678;
  --accent:#5eead4; --accent2:#38bdf8; --pos:#34d399; --neg:#f87171;
  --warn:#fbbf24; --sniper:#34d399; --buy:#60a5fa; --watch:#94a3b8;
  --shadow:0 4px 20px rgba(0,0,0,.4);
}
html[data-theme="light"]{
  --bg:#f4f6fb; --bg2:#ffffff; --card:#ffffff; --card2:#f0f3fa;
  --border:#e2e8f3; --text:#1a2236; --muted:#5c6678; --dim:#94a0b4;
  --accent:#0d9488; --accent2:#0284c7; --pos:#059669; --neg:#dc2626;
  --warn:#d97706; --sniper:#059669; --buy:#2563eb; --watch:#64748b;
  --shadow:0 4px 20px rgba(100,116,139,.12);
}
*{box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',system-ui,sans-serif;
  background:var(--bg);color:var(--text);margin:0;padding:0;
  transition:background .25s,color .25s;-webkit-font-smoothing:antialiased}
.wrap{max-width:1240px;margin:0 auto;padding:20px 16px 60px}
header{display:flex;align-items:center;gap:14px;flex-wrap:wrap;
  padding:18px 0 14px;position:sticky;top:0;background:var(--bg);z-index:10;
  border-bottom:1px solid var(--border)}
.logo{font-size:22px;font-weight:800;letter-spacing:-.5px;display:flex;align-items:center;gap:9px}
.logo .dot{width:10px;height:10px;border-radius:50%;background:var(--pos);
  box-shadow:0 0 12px var(--pos);animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
.tag{font-size:11px;font-weight:700;padding:3px 9px;border-radius:20px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));color:#03121a}
.spacer{flex:1}
.upd{font-size:12px;color:var(--dim)}
.toggle{cursor:pointer;border:1px solid var(--border);background:var(--card);
  color:var(--text);border-radius:20px;padding:7px 14px;font-size:13px;font-weight:600;
  display:flex;align-items:center;gap:7px;transition:.2s}
.toggle:hover{border-color:var(--accent);transform:translateY(-1px)}
h2{font-size:13px;color:var(--muted);margin:30px 0 12px;text-transform:uppercase;
  letter-spacing:1.2px;font-weight:700;display:flex;align-items:center;gap:8px}
h2 .line{flex:1;height:1px;background:var(--border)}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:13px}
.card{background:var(--card);padding:16px 17px;border-radius:14px;border:1px solid var(--border);
  box-shadow:var(--shadow);transition:transform .15s,border-color .15s}
.card:hover{transform:translateY(-2px);border-color:var(--accent)}
.card.hl{background:linear-gradient(145deg,var(--card),var(--card2));border-color:var(--accent)}
.label{color:var(--dim);font-size:11px;text-transform:uppercase;letter-spacing:.6px;font-weight:600}
.value{font-size:26px;font-weight:800;margin-top:6px;letter-spacing:-.5px}
.value.sm{font-size:14px;font-weight:600}
.tablewrap{overflow-x:auto;border-radius:14px;border:1px solid var(--border);box-shadow:var(--shadow)}
table{width:100%;border-collapse:collapse;background:var(--card);min-width:680px}
th,td{padding:11px 13px;text-align:left;font-size:13px;border-bottom:1px solid var(--border)}
th{background:var(--card2);color:var(--muted);font-weight:600;text-transform:uppercase;
  font-size:11px;letter-spacing:.5px;position:sticky;top:0}
tr:last-child td{border-bottom:none}
tbody tr{transition:background .12s}
tbody tr:hover{background:var(--card2)}
.badge{padding:3px 9px;border-radius:6px;font-size:11px;font-weight:700;white-space:nowrap}
.b-sniper{background:color-mix(in srgb,var(--sniper) 22%,transparent);color:var(--sniper)}
.b-buy{background:color-mix(in srgb,var(--buy) 22%,transparent);color:var(--buy)}
.b-watch{background:color-mix(in srgb,var(--watch) 22%,transparent);color:var(--watch)}
.sm-badge{background:color-mix(in srgb,var(--warn) 20%,transparent);color:var(--warn);
  padding:3px 8px;border-radius:6px;font-weight:800;font-size:11px;white-space:nowrap}
.risk-low{color:var(--pos);font-weight:600}.risk-medium{color:var(--warn);font-weight:600}
.risk-high{color:var(--neg);font-weight:600}
.pos{color:var(--pos)}.neg{color:var(--neg)}
code{font-family:'SF Mono',Menlo,monospace;font-size:12px;background:var(--card2);
  padding:2px 6px;border-radius:5px}
a{color:var(--accent);text-decoration:none;font-weight:600}
a:hover{text-decoration:underline}
.empty{text-align:center;color:var(--dim);padding:26px!important;font-style:italic}
.pill{font-size:11px;padding:2px 8px;border-radius:20px;background:var(--card2);color:var(--muted);font-weight:600}
@media(max-width:600px){.value{font-size:22px}.wrap{padding:14px 10px 50px}}
</style></head>
<body>
<div class="wrap">
<header>
  <div class="logo"><span class="dot"></span>SolSniper</div>
  <span class="tag">CONVICTION MODE</span>
  <div class="spacer"></div>
  <span class="upd" id="upd">connecting…</span>
  <button class="toggle" id="themeBtn" onclick="toggleTheme()"><span id="themeIcon">🌙</span><span id="themeTxt">Dark</span></button>
</header>

<h2>Overview<span class="line"></span></h2>
<div class="grid" id="stats"></div>

<h2>🐋 Smart Money · Live <span class="pill">last 15 min</span><span class="line"></span></h2>
<div class="tablewrap">
<table id="smart"><thead><tr><th>Token</th><th>Wallets</th><th>Total SOL</th><th>Age</th></tr></thead><tbody></tbody></table>
</div>

<h2>📊 Performance<span class="line"></span></h2>
<div class="grid" id="perf"></div>

<h2>📡 Recent Signals <span class="pill">top 50</span><span class="line"></span></h2>
<div class="tablewrap">
<table id="signals"><thead><tr>
<th>Time</th><th>Tier</th><th>Symbol</th><th>Score</th><th>🐋</th><th>Risk</th>
<th>1h</th><th>Liq</th><th>MCap</th><th>Links</th>
</tr></thead><tbody></tbody></table>
</div>
</div>

<script>
const TOKEN=new URLSearchParams(location.search).get('token')||'';
const $=id=>document.getElementById(id);
async function api(p){return (await fetch(p+'?token='+TOKEN)).json()}
function fmt$(n){const v=Number(n)||0;
  if(v>=1e6)return '$'+(v/1e6).toFixed(1)+'M';
  if(v>=1e3)return '$'+(v/1e3).toFixed(0)+'K';return '$'+v.toFixed(0)}
function tierClass(l){l=(l||'').toUpperCase();
  return l.includes('SNIPER')?'b-sniper':l.includes('BUY')?'b-buy':'b-watch'}
function riskClass(r){return 'risk-'+((r||'low').toLowerCase())}

/* theme */
function applyTheme(t){
  document.documentElement.setAttribute('data-theme',t);
  $('themeIcon').textContent=t==='light'?'☀️':'🌙';
  $('themeTxt').textContent=t==='light'?'Light':'Dark';
}
function toggleTheme(){
  const cur=document.documentElement.getAttribute('data-theme')==='light'?'dark':'light';
  applyTheme(cur);try{localStorage.setItem('ss_theme',cur)}catch(e){}
}
(function(){let t='dark';try{t=localStorage.getItem('ss_theme')||'dark'}catch(e){}applyTheme(t)})();

async function refresh(){
 try{
  const s=await api('/api/stats');
  $('stats').innerHTML=`
   <div class="card"><div class="label">Scans</div><div class="value">${s.scans??0}</div></div>
   <div class="card"><div class="label">Total Alerts</div><div class="value pos">${s.signals??0}</div></div>
   <div class="card hl"><div class="label">🐋 Smart-Money Hits</div><div class="value pos">${s.smart_money_signals??0}</div></div>
   <div class="card"><div class="label">🎯 Snipers</div><div class="value">${s.strong_buys??s.sniper_alerts??0}</div></div>
   <div class="card"><div class="label">Wallets Tracked</div><div class="value">${s.wallets_tracked??0}</div></div>
   <div class="card"><div class="label">Last Scan</div><div class="value sm">${(s.last_scan||'—').toString().slice(11,19)||'—'}</div></div>`;

  const sm=await api('/api/smart_money');
  document.querySelector('#smart tbody').innerHTML=sm.length?sm.map(x=>
   `<tr><td><a href="https://dexscreener.com/solana/${x.mint}" target="_blank"><code>${x.mint.slice(0,10)}…</code></a></td>
    <td><b>${x.wallet_count}</b></td><td>${(x.total_sol||0).toFixed(2)} ◎</td>
    <td>${(x.oldest_min||0).toFixed(0)}m</td></tr>`).join('')
   :'<tr><td colspan="4" class="empty">No smart-money clusters in the last 15 minutes</td></tr>';

  const p=await api('/api/performance');
  if(p.total_tracked>0){
   $('perf').innerHTML=`
    <div class="card"><div class="label">Tracked</div><div class="value">${p.total_tracked}</div></div>
    <div class="card"><div class="label">Win Rate · 1h</div><div class="value pos">${p.win_rate_1h??'—'}%</div></div>
    <div class="card"><div class="label">Avg PnL · 1h</div><div class="value ${(p.avg_pnl_1h>=0)?'pos':'neg'}">${(p.avg_pnl_1h>=0?'+':'')}${p.avg_pnl_1h??0}%</div></div>
    <div class="card hl"><div class="label">Avg Peak PnL</div><div class="value pos">+${p.avg_peak_pnl??0}%</div></div>`;
  }else{
   $('perf').innerHTML='<div class="card"><div class="label">Status</div><div class="value sm">Collecting data — need 1h+ of alerts</div></div>';
  }

  const sigs=await api('/api/signals');
  document.querySelector('#signals tbody').innerHTML=sigs.length?sigs.map(x=>
   `<tr><td>${(x.created_at||'').slice(11,16)}</td>
    <td><span class="badge ${tierClass(x.label)}">${x.label}</span></td>
    <td><b>${x.symbol||'?'}</b></td><td>${x.score??''}</td>
    <td>${x.smart_money_count>0?'<span class="sm-badge">🐋×'+x.smart_money_count+'</span>':''}</td>
    <td><span class="${riskClass(x.risk_level)}">${x.risk_level||'?'}</span></td>
    <td class="pos">+${Number(x.change_1h||0).toFixed(0)}%</td>
    <td>${fmt$(x.liquidity)}</td><td>${fmt$(x.mcap)}</td>
    <td><a href="${x.dex_url}" target="_blank">DEX</a> · <a href="https://rugcheck.xyz/tokens/${x.address}" target="_blank">RC</a></td></tr>`).join('')
   :'<tr><td colspan="10" class="empty">No signals yet — the bot will populate this as it scans</td></tr>';

  $('upd').textContent='● live · '+new Date().toLocaleTimeString();
  $('upd').style.color='var(--pos)';
 }catch(e){$('upd').textContent='⚠ '+e.message;$('upd').style.color='var(--neg)'}
}
refresh();setInterval(refresh,5000);
</script></body></html>"""

@app.route("/")
def index():
    require_auth()
    return render_template_string(INDEX_HTML)

@app.route("/api/stats")
def api_stats():
    require_auth()
    s = db.get_summary_stats()
    s["wallets_tracked"] = len(smart_money.load_wallets())
    return jsonify(s)

@app.route("/api/signals")
def api_signals():
    require_auth()
    return jsonify(db.recent_signals(50))

@app.route("/api/smart_money")
def api_smart_money():
    require_auth()
    return jsonify(smart_money.top_recent_tokens(min_wallets=1, top_n=15))

@app.route("/api/performance")
def api_performance():
    require_auth()
    return jsonify(outcome_tracker.get_performance_stats())

if __name__ == "__main__":
    if not config.DASHBOARD_TOKEN:
        log.error("DASHBOARD_TOKEN not set"); raise SystemExit(1)
    log.info(f"Dashboard on 0.0.0.0:{config.DASHBOARD_PORT}")
    app.run(host="0.0.0.0", port=config.DASHBOARD_PORT, debug=False)
