"""SolSniper Conviction Mode — main entry point.
Threads:
  - scanner_loop       : DexScreener + multi-layer confirmation
  - smart_money loop   : poll tracked wallets
  - on_chain monitor   : LP/dev/continuation alerts
  - outcome_tracker    : 1h/6h/24h outcomes
  - self_tuner_loop    : daily tuning report
  - telegram listener  : commands
  - heartbeat
"""
import os
import sys
import time
import signal as sigmod
import logging
import threading
import requests

import config
import db
import scanner
import telegram as tg
import smart_money
import on_chain_monitor
import outcome_tracker
import trending
import self_tuner
import wallet_discovery

os.makedirs(config.LOG_DIR, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(threadName)s] %(levelname)s %(message)s",
    handlers=[
        logging.FileHandler(os.path.join(config.LOG_DIR, "bot.log")),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger("SolSniper")

STATE = {"running": True, "paused": False}
_last_scan_err_tg = 0.0  # epoch of last scanner-error Telegram (throttle)

def scanner_loop():
    log.info(f"Scanner started (Conviction Mode, interval={config.SCAN_INTERVAL}s)")
    while STATE["running"]:
        try:
            if STATE["paused"]:
                time.sleep(config.SCAN_INTERVAL); continue

            db.stat_inc("scans")
            db.stat_set("last_scan", db.now_iso())
            db.prune_seen(5000)

            profiles = scanner.fetch_latest_profiles()
            gecko = scanner.fetch_geckoterminal_candidates()
            # Tag origin for per-source attribution
            for g in (gecko or []): g["_source"] = "geckoterminal"
            for d in (profiles or []): d["_source"] = "dexscreener"
            combined = (gecko or []) + (profiles or [])
            if not combined:
                log.warning("No candidates from any source this cycle")
                _sleep_responsive(config.SCAN_INTERVAL); continue
            log.info(f"Candidates this scan: {len(gecko or [])} gecko + {len(profiles or [])} dex = {len(combined)}")

            if profiles:
                trending.record_ranks(profiles)

            new_count = 0
            for p in combined[:120]:
                if not STATE["running"]: break
                # ── Per-token isolation: a single malformed token (e.g. a brand-new
                # firehose pool whose rug/holder API returns null) must NEVER abort
                # the whole scan or fire a Telegram alert. Skip it and move on.
                try:
                    addr = p.get("tokenAddress", "")
                    if not addr or p.get("chainId") != "solana": continue
                    if db.has_seen(addr): continue
                    db.mark_seen(addr)

                    signal = scanner.evaluate_token(addr, source=p.get("_source", "unknown"))
                    if signal is None: continue

                    signal_id = db.save_signal(signal)
                    db.stat_inc("signals")
                    if "SNIPER" in signal["label"]:
                        db.stat_inc("sniper_alerts")
                    if signal.get("smart_money", {}).get("count", 0) > 0:
                        db.stat_inc("smart_money_signals")

                    new_count += 1
                    sm = signal.get("smart_money", {})
                    log.info(
                        f"📡 {signal['label']} {signal['symbol']} | s{signal['score']} "
                        f"+{signal['change_1h']:.1f}% | 🐋×{sm.get('count', 0)} | "
                        f"layers: {','.join(signal.get('confirmations', []))}"
                    )

                    # Private alert
                    tg.send(tg.format_signal(signal))

                    # Public broadcast for SNIPER-tier only
                    tg.broadcast_if_sniper(signal)

                    # Track outcome
                    outcome_tracker.record_signal(
                        signal_id, signal["address"], signal["symbol"],
                        signal["label"], signal["score"], signal["price"],
                    )
                    # Begin monitoring
                    on_chain_monitor.start_tracking(
                        signal["address"], signal["liquidity"], signal["price"]
                    )

                    time.sleep(0.8)
                except Exception as te:
                    log.debug(f"  token {p.get('tokenAddress','?')[:8]}… skipped: {te}")
                    continue

            if new_count > 0:
                rate = scanner.get_rate_status()
                log.info(
                    f"Scan done: {new_count} alerts | "
                    f"24h: {rate['last_24h']} (🎯{rate['sniper_24h']} 🟢{rate['buy_24h']} 👀{rate['watch_24h']})"
                )
        except Exception as e:
            log.exception(f"Scanner error: {e}")
            # Throttle: log every time, but Telegram at most once per 10 min so a
            # persistent fault can never flood the user's phone.
            global _last_scan_err_tg
            if time.time() - _last_scan_err_tg > 600:
                _last_scan_err_tg = time.time()
                tg.send(f"⚠️ Scanner error (throttled 10m): `{str(e)[:150]}`")

        _sleep_responsive(config.SCAN_INTERVAL)

def _sleep_responsive(seconds: int):
    for _ in range(seconds):
        if not STATE["running"]: return
        time.sleep(1)

def heartbeat_loop():
    if not config.HEARTBEAT_URL:
        log.info("Heartbeat disabled"); return
    while STATE["running"]:
        try: requests.get(config.HEARTBEAT_URL, timeout=10)
        except Exception: pass
        for _ in range(300):
            if not STATE["running"]: return
            time.sleep(1)

def self_tune_loop():
    """Every 24h, generate a self-tuning report and Telegram it."""
    log.info("Self-tuning loop started (daily reports)")
    # Wait 1 hour after startup before first analysis
    for _ in range(3600):
        if not STATE["running"]: return
        time.sleep(1)
    while STATE["running"]:
        try:
            analysis = self_tuner.analyze_outcomes()
            if analysis:
                tg.send(self_tuner.format_tuning_report(analysis))
                log.info("Self-tuning report sent")
        except Exception as e:
            log.exception(f"Self-tuner error: {e}")
        # Sleep 24 hours
        for _ in range(86400):
            if not STATE["running"]: return
            time.sleep(1)

def shutdown_handler(signum, frame):
    log.info(f"Signal {signum} — shutting down")
    STATE["running"] = False
    tg.send("🛑 SolSniper shutting down")

def main():
    log.info("=" * 60)
    log.info("SolSniper — CONVICTION MODE (Adaptive Cap)")
    log.info(f"Quality-first alerts with smart throttling")
    log.info(f"Score floor: {config.MIN_ALERT_SCORE} | SNIPER tier: {config.SNIPER_SCORE}")
    log.info(f"Required confirmation layers: {config.MIN_CONFIRMATION_LAYERS}")
    log.info(f"Burst: {config.MAX_ALERTS_PER_10MIN}/10min | Hour: {config.MAX_ALERTS_PER_HOUR}/hr")
    log.info(f"24h tier caps: SNIPER={config.MAX_SNIPER_PER_24H or '∞'} BUY={config.MAX_BUY_PER_24H} WATCH={config.MAX_WATCH_PER_24H}")
    log.info(f"Exceptional bypass: {config.EXCEPTIONAL_MIN_SMART_WALLETS}+ smart wallets OR score≥{config.EXCEPTIONAL_MIN_SCORE}")
    log.info(f"Per-token cooldown: {config.PER_TOKEN_COOLDOWN_HOURS}h")
    log.info("=" * 60)

    db.init_db()
    outcome_tracker.init_table()
    log.info(f"Smart wallets tracked: {len(smart_money.load_wallets())}")

    sigmod.signal(sigmod.SIGTERM, shutdown_handler)
    sigmod.signal(sigmod.SIGINT,  shutdown_handler)

    threads = [
        threading.Thread(target=scanner_loop, name="Scanner", daemon=True),
        threading.Thread(target=smart_money.polling_loop, args=(STATE,), name="SmartMoney", daemon=True),
        threading.Thread(target=on_chain_monitor.monitor_loop, args=(STATE, tg.send), name="OnChain", daemon=True),
        threading.Thread(target=outcome_tracker.check_outcomes, args=(STATE,), name="Outcomes", daemon=True),
        threading.Thread(target=self_tune_loop, name="SelfTuner", daemon=True),
        threading.Thread(target=wallet_discovery.discovery_loop, args=(STATE,), name="Discovery", daemon=True),
        threading.Thread(target=tg.listen, args=(STATE,), name="Telegram", daemon=True),
        threading.Thread(target=heartbeat_loop, name="Heartbeat", daemon=True),
    ]
    for t in threads: t.start()

    log.info("All threads running.")
    try:
        while STATE["running"]: time.sleep(1)
    except KeyboardInterrupt:
        STATE["running"] = False

    for t in threads: t.join(timeout=5)
    log.info("Shutdown complete.")

if __name__ == "__main__":
    main()
