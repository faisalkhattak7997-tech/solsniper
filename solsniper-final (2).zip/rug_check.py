"""Multi-source rug detection — Conviction Mode.
RugCheck + GoPlus + on-chain holder concentration."""
import logging
import requests
from typing import Tuple, List, Dict, Any

import config
from http_utils import http_get

log = logging.getLogger("SolSniper")

# ─────────────────────────────────────────
# RUGCHECK
# ─────────────────────────────────────────
def check_rugcheck(token_address: str) -> Dict[str, Any]:
    result = {"ok": True, "fails": [], "warnings": [], "score": 0, "source": "rugcheck"}
    data = http_get(
        f"https://api.rugcheck.xyz/v1/tokens/{token_address}/report/summary",
        timeout=8, retries=2
    )
    if not data:
        result["warnings"].append("rugcheck unavailable")
        return result
    try:
        score = int(data.get("score") or 0)
        result["score"] = score
        risks = data.get("risks", []) or []
        for r in risks:
            name = (r.get("name") or "").lower()
            level = (r.get("level") or "").lower()
            if "mint authority" in name and level == "danger":
                result["fails"].append("mint_authority_active")
            elif "freeze authority" in name and level == "danger":
                result["fails"].append("freeze_authority_active")
            elif ("lp" in name or "liquidity" in name) and level == "danger":
                if "not locked" in name or "not burned" in name or "unlocked" in name:
                    result["fails"].append("lp_not_locked_or_burned")
            elif "honeypot" in name:
                result["fails"].append("honeypot_detected")
            elif "high holder concentration" in name and level == "danger":
                result["fails"].append("top10_concentration_high")
            elif level in ("warn", "warning"):
                result["warnings"].append(name)
        if score > config.RUGCHECK_MAX_RISK:
            result["fails"].append(f"rugcheck_score_{score}")
        result["ok"] = len(result["fails"]) == 0
    except Exception as e:
        log.debug(f"rugcheck parse error: {e}")
        result["warnings"].append("rugcheck parse error")
    return result

# ─────────────────────────────────────────
# GOPLUS
# ─────────────────────────────────────────
def check_goplus(token_address: str) -> Dict[str, Any]:
    result = {"ok": True, "fails": [], "warnings": [], "source": "goplus"}
    url = f"https://api.gopluslabs.io/api/v1/solana/token_security?contract_addresses={token_address}"
    data = http_get(url, timeout=10, retries=2)
    if not data:
        result["warnings"].append("goplus unavailable"); return result
    try:
        token_info = (data.get("result") or {}).get(token_address)
        if not token_info:
            results = data.get("result") or {}
            for k, v in results.items():
                if k.lower() == token_address.lower():
                    token_info = v; break
        if not token_info:
            result["warnings"].append("goplus no data"); return result

        mintable = token_info.get("mintable") or {}
        freezable = token_info.get("freezable") or {}
        transfer_fee = token_info.get("transfer_fee") or {}
        balance_mutable = token_info.get("balance_mutable_authority") or {}
        non_transferable = token_info.get("non_transferable")
        metadata = token_info.get("metadata") or {}

        if str(mintable.get("status", "0")) == "1":
            result["fails"].append("mint_authority_active")
        if str(freezable.get("status", "0")) == "1":
            result["fails"].append("freeze_authority_active")
        if non_transferable == "1" or non_transferable is True:
            result["fails"].append("honeypot_detected")
        try:
            fee_pct = float(transfer_fee.get("transfer_fee_upper_percent") or 0)
            if fee_pct > 10:
                result["fails"].append("transfer_fee_excessive")
            elif fee_pct > 5:
                result["warnings"].append(f"transfer_fee_{fee_pct:.1f}%")
        except (TypeError, ValueError):
            pass
        if str(balance_mutable.get("status", "0")) == "1":
            result["fails"].append("balance_mutable")
        if str(metadata.get("trusted_token", "0")) == "1":
            result["warnings"] = []; result["fails"] = []
        result["ok"] = len(result["fails"]) == 0
    except Exception as e:
        log.debug(f"goplus parse error: {e}")
        result["warnings"].append("goplus parse error")
    return result

# ─────────────────────────────────────────
# HOLDERS
# ─────────────────────────────────────────
def check_holder_concentration(token_address: str) -> Dict[str, Any]:
    max_pct = config.TOP10_MAX_PCT
    result = {"ok": True, "fails": [], "warnings": [], "top10_pct": 0, "source": "holders"}
    try:
        r = requests.post(config.SOLANA_RPC, json={
            "jsonrpc": "2.0", "id": 1,
            "method": "getTokenLargestAccounts",
            "params": [token_address],
        }, timeout=10)
        accounts = r.json().get("result", {}).get("value", [])
        if not accounts:
            result["warnings"].append("no holder data"); return result

        sup_r = requests.post(config.SOLANA_RPC, json={
            "jsonrpc": "2.0", "id": 1,
            "method": "getTokenSupply",
            "params": [token_address],
        }, timeout=10)
        supply = float(sup_r.json().get("result", {}).get("value", {}).get("uiAmount") or 0)
        if supply <= 0:
            result["warnings"].append("supply unknown"); return result

        top10 = sum(float(a.get("uiAmount") or 0) for a in accounts[:10])
        top10_pct = (top10 / supply) * 100
        result["top10_pct"] = round(top10_pct, 1)

        # Exclude LP from #1 if it's clearly the pool
        if accounts and float(accounts[0].get("uiAmount") or 0) / supply > 0.40:
            top10_excl = sum(float(a.get("uiAmount") or 0) for a in accounts[1:10])
            top10_pct_excl = (top10_excl / supply) * 100
            result["top10_pct_excl_lp"] = round(top10_pct_excl, 1)
            top10_pct = top10_pct_excl

        if top10_pct > max_pct:
            result["fails"].append("top10_concentration_high")
        elif top10_pct > 25:
            result["warnings"].append(f"top10_holders_{top10_pct:.0f}pct")
        result["ok"] = len(result["fails"]) == 0
    except Exception as e:
        log.debug(f"holder check error: {e}")
        result["warnings"].append("holder check error")
    return result

# ─────────────────────────────────────────
# COMBINED
# ─────────────────────────────────────────
def comprehensive_rug_check(token_address: str) -> Dict[str, Any]:
    rc = check_rugcheck(token_address)
    gp = check_goplus(token_address)
    ho = check_holder_concentration(token_address)

    # Defensive: coerce every sub-check's fails/warnings to a list, so even a
    # stale/older sub-check returning None can never raise 'NoneType not iterable'.
    def _lst(d, key):
        v = (d or {}).get(key)
        return v if isinstance(v, list) else []
    all_fails = list(set(_lst(rc, "fails") + _lst(gp, "fails") + _lst(ho, "fails")))
    INFRA_NOISE = {
        "rugcheck unavailable", "goplus unavailable",
        "rugcheck parse error", "goplus parse error",
        "goplus no data", "no holder data", "supply unknown",
        "holder check error", "rugcheck error (allowed)",
    }
    all_warnings = list(set(w for w in (_lst(rc, "warnings") + _lst(gp, "warnings") + _lst(ho, "warnings")) if w not in INFRA_NOISE))

    safe = len(all_fails) == 0
    rc_unreachable = "rugcheck unavailable" in _lst(rc, "warnings")
    gp_unreachable = "goplus unavailable" in _lst(gp, "warnings")
    if rc_unreachable and gp_unreachable:
        # Conviction mode: if both rug sources are down, REJECT (cautious)
        return {
            "safe": False, "risk_level": "UNKNOWN",
            "fails": ["rug_apis_unreachable"],
            "warnings": all_warnings,
            "summary_lines": ["Rug check APIs unavailable — alert suppressed"],
            "details": {"rugcheck": rc, "goplus": gp, "holders": ho},
        }

    if not safe: risk_level = "HIGH"
    elif len(all_warnings) == 0: risk_level = "LOW"
    elif len(all_warnings) <= 2: risk_level = "MEDIUM"
    else: risk_level = "HIGH"

    lines = []
    lines.append("Mint: " + ("NOT renounced ✗" if "mint_authority_active" in all_fails else "Renounced ✓"))
    lines.append("Freeze: " + ("NOT renounced ✗" if "freeze_authority_active" in all_fails else "Renounced ✓"))
    lines.append("LP: " + ("NOT locked/burned ✗" if "lp_not_locked_or_burned" in all_fails else "Locked/burned ✓"))
    if "honeypot_detected" in all_fails:
        lines.append("Honeypot: YES ✗")
    elif "transfer_fee_excessive" in all_fails:
        lines.append("Sell tax: Excessive ✗")
    else:
        lines.append("Honeypot: NO ✓")
    top10 = ho.get("top10_pct_excl_lp") or ho.get("top10_pct")
    if top10:
        marker = "✗" if "top10_concentration_high" in all_fails else "✓"
        lines.append(f"Top 10 holders: {top10:.0f}% {marker}")

    return {
        "safe": safe, "risk_level": risk_level,
        "fails": all_fails, "warnings": all_warnings,
        "summary_lines": lines,
        "details": {"rugcheck": rc, "goplus": gp, "holders": ho},
    }
