"""HTTP helpers with retry + exponential backoff."""
import time
import logging
from typing import Optional, Any
import requests

log = logging.getLogger("SolSniper")

def http_get(url: str, *, params=None, timeout=10, retries=3, headers=None) -> Optional[Any]:
    delay = 1.0
    for attempt in range(retries):
        try:
            r = requests.get(url, params=params, timeout=timeout, headers=headers)
            if r.status_code == 429:
                log.warning(f"429 on GET {url} — backoff {delay:.1f}s")
                time.sleep(delay); delay *= 2; continue
            if r.status_code >= 500:
                time.sleep(delay); delay *= 2; continue
            r.raise_for_status()
            return r.json()
        except requests.RequestException as e:
            if attempt == retries - 1:
                log.error(f"GET {url} failed after {retries}: {e}")
                return None
            time.sleep(delay); delay *= 2
    return None

def http_post(url: str, *, json_body=None, timeout=15, retries=3) -> Optional[Any]:
    delay = 1.0
    for attempt in range(retries):
        try:
            r = requests.post(url, json=json_body, timeout=timeout)
            if r.status_code == 429:
                log.warning(f"429 on POST {url} — backoff {delay:.1f}s")
                time.sleep(delay); delay *= 2; continue
            if r.status_code >= 500:
                time.sleep(delay); delay *= 2; continue
            r.raise_for_status()
            return r.json()
        except requests.RequestException as e:
            if attempt == retries - 1:
                log.error(f"POST {url} failed after {retries}: {e}")
                return None
            time.sleep(delay); delay *= 2
    return None
