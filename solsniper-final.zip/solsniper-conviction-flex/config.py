"""SolSniper Conviction Mode — tuned for 3-10 quality alerts per day.

Philosophy: zero tolerance for mediocre signals. A signal from this bot
must pass multiple independent confirmation layers. Most other bots are
volume-driven; this one is conviction-driven.
"""
import os
from dotenv import load_dotenv

load_dotenv()

def _f(k, d): return float(os.environ.get(k, d))
def _i(k, d): return int(os.environ.get(k, d))
def _s(k, d=""): return os.environ.get(k, d)
def _b(k, d): return os.environ.get(k, d).lower() == "true"

# ─── Loop ───
SCAN_INTERVAL    = _i("SCAN_INTERVAL", "30")

# ─── Conviction Filters (intentionally aggressive) ───
MIN_LIQUIDITY    = _f("MIN_LIQUIDITY", "60000")
MAX_LIQUIDITY    = _f("MAX_LIQUIDITY", "800000")
MIN_VOL_1H       = _f("MIN_VOL_1H", "200000")
MIN_VOL_LIQ_RATIO = _f("MIN_VOL_LIQ_RATIO", "0.7")  # anti-wash-trade
MIN_CHANGE_1H    = _f("MIN_CHANGE_1H", "50.0")
MIN_AGE_MIN      = _f("MIN_AGE_MIN", "10")
MAX_AGE_MIN      = _f("MAX_AGE_MIN", "180")
MIN_MCAP         = _f("MIN_MCAP", "50000")
MAX_MCAP         = _f("MAX_MCAP", "3000000")
MIN_TXNS_1H      = _i("MIN_TXNS_1H", "200")
MIN_BUY_RATIO    = _f("MIN_BUY_RATIO", "1.8")

# ─── Score gate ───
MIN_ALERT_SCORE  = _i("MIN_ALERT_SCORE", "80")
SNIPER_SCORE     = _i("SNIPER_SCORE", "90")  # absolute top tier

# ─── Multi-confirmation requirement ───
# A signal needs at least N "layers" to fire:
#   - filters_passed (always 1 if reaches this stage)
#   - smart_money_confirmed (2+ tracked wallets bought)
#   - velocity_confirmed (rank climbed 15+)
#   - social_confirmed (10+ X mentions)
#   - momentum_confirmed (score >= 85)
MIN_CONFIRMATION_LAYERS = _i("MIN_CONFIRMATION_LAYERS", "2")

# ─── Smart money ───
SMART_MONEY_BOOST_THRESHOLD = _i("SMART_MONEY_BOOST_THRESHOLD", "2")
SMART_MONEY_AUTO_PROMOTE = _b("SMART_MONEY_AUTO_PROMOTE", "true")

# ─── Rug check (stricter than v3) ───
RUGCHECK_MAX_RISK   = _i("RUGCHECK_MAX_RISK", "1000")  # tighter
TOP10_MAX_PCT       = _f("TOP10_MAX_PCT", "40")        # was 50 in v3

# ─── Rate limiting (Adaptive Cap) ───
PER_TOKEN_COOLDOWN_HOURS = _f("PER_TOKEN_COOLDOWN_HOURS", "24")

# Time-windowed caps (anti-spam, no fixed daily limit)
MAX_ALERTS_PER_10MIN = _i("MAX_ALERTS_PER_10MIN", "3")
MAX_ALERTS_PER_HOUR  = _i("MAX_ALERTS_PER_HOUR", "8")

# Tier-specific caps within a rolling 24h window
# 0 = unlimited
MAX_SNIPER_PER_24H = _i("MAX_SNIPER_PER_24H", "0")   # never cap SNIPER
MAX_BUY_PER_24H    = _i("MAX_BUY_PER_24H", "12")
MAX_WATCH_PER_24H  = _i("MAX_WATCH_PER_24H", "4")

# Exceptional-signal bypass: these always fire regardless of caps
EXCEPTIONAL_MIN_SMART_WALLETS = _i("EXCEPTIONAL_MIN_SMART_WALLETS", "4")
EXCEPTIONAL_MIN_SCORE = _i("EXCEPTIONAL_MIN_SCORE", "95")

# Legacy single-cap fallback (used when /flex off)
STRICT_MAX_ALERTS_PER_DAY = _i("STRICT_MAX_ALERTS_PER_DAY", "10")

# ─── Time-of-day awareness ───
# During "dead hours" (UTC), require higher score
USE_TIME_OF_DAY_FILTER = _b("USE_TIME_OF_DAY_FILTER", "true")
DEAD_HOURS_UTC_START = _i("DEAD_HOURS_UTC_START", "6")
DEAD_HOURS_UTC_END   = _i("DEAD_HOURS_UTC_END", "12")
DEAD_HOURS_MIN_SCORE = _i("DEAD_HOURS_MIN_SCORE", "85")

# ─── Self-tuning ───
# After this many tracked outcomes, auto-adjust threshold based on win rates
SELF_TUNE_AFTER_N_OUTCOMES = _i("SELF_TUNE_AFTER_N_OUTCOMES", "50")
USE_SELF_TUNING = _b("USE_SELF_TUNING", "true")

# ─── Social ───
USE_SOCIAL_CHECK = _b("USE_SOCIAL_CHECK", "true")
SOCIAL_CONFIRMATION_THRESHOLD = _i("SOCIAL_CONFIRMATION_THRESHOLD", "10")

# ─── Velocity ───
VELOCITY_CONFIRMATION_RANK_CHANGE = _i("VELOCITY_CONFIRMATION_RANK_CHANGE", "15")

# ─── Endpoints ───
DEXSCREENER_PROFILES = "https://api.dexscreener.com/token-profiles/latest/v1"
DEXSCREENER_TOKENS   = "https://api.dexscreener.com/latest/dex/tokens/{}"
# GeckoTerminal new-pools — a real discovery firehose (free, no key).
# This is the fix for signal starvation: DexScreener profiles alone is a trickle.
GECKOTERMINAL_NEW_POOLS = "https://api.geckoterminal.com/api/v2/networks/solana/new_pools?page={}"
GECKOTERMINAL_TRENDING  = "https://api.geckoterminal.com/api/v2/networks/solana/trending_pools?page=1"
USE_GECKOTERMINAL = os.environ.get("USE_GECKOTERMINAL", "true").lower() == "true"
GECKO_PAGES = int(os.environ.get("GECKO_PAGES", "3"))  # 3 pages ≈ 60 fresh pools/scan
SOLANA_RPC           = _s("SOLANA_RPC", "https://api.mainnet-beta.solana.com")
SOL_MINT             = "So11111111111111111111111111111111111111112"

# ─── Persistence ───
LOG_DIR = _s("LOG_DIR", "./logs")
DB_DIR  = _s("DB_DIR", "./data")
DB_PATH = _s("DB_PATH", os.path.join(DB_DIR, "signals.db"))

# ─── Telegram ───
TELEGRAM_TOKEN   = _s("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = _s("TELEGRAM_CHAT_ID", "")

# ─── Broadcast mode (for later public channel use) ───
BROADCAST_CHANNEL_ID = _s("BROADCAST_CHANNEL_ID", "")  # optional secondary chat for SNIPER-only posts

# ─── Health ───
HEARTBEAT_URL = _s("HEARTBEAT_URL", "")

# ─── Dashboard ───
DASHBOARD_PORT  = _i("DASHBOARD_PORT", "8080")
DASHBOARD_TOKEN = _s("DASHBOARD_TOKEN", "")
