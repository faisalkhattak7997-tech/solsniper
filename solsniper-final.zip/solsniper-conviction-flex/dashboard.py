"""SolSniper v3 dashboard."""
import os
import json
import logging
from flask import Flask, jsonify, request, render_template_string, abort

import config
import db
import smart_money
import outcome_tracker

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("Dashboard")
app = Flask(__name__)

def require_auth():
    if not config.DASHBOARD_TOKEN:
        abort(503, "Dashboard disabled")
    token = request.args.get("token") or request.headers.get("X-Auth-Token", "")
    if token != config.DASHBOARD_TOKEN:
        abort(401, "Invalid token")

INDEX_HTML = """<!doctype html>
<html><head><title>SolSniper v3</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{font-family:-apple-system,system-ui,sans-serif;background:#0a0e1a;color:#e0e6ed;margin:0;padding:20px}
h1{color:#4fd1c5;display:flex;align-items:center;gap:8px}
h2{color:#9ca3af;font-size:16px;margin-top:32px;text-transform:uppercase;letter-spacing:1px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:16px}
.card{background:#131826;padding:14px;border-radius:8px;border:1px solid #1f2937}
.card.highlight{border-color:#4fd1c5}
.label{color:#6b7280;font-size:11px;text-transform:uppercase}
.value{font-size:22px;font-weight:600;margin-top:4px}
table{width:100%;border-collapse:collapse;background:#131826;border-radius:8px;overflow:hidden}
th,td{padding:8px 10px;text-align:left;border-bottom:1px solid #1f2937;font-size:12px}
th{background:#1f2937;color:#9ca3af;font-weight:500}
tr:hover{background:#1a1f2e}
.badge{padding:2px 6px;border-radius:4px;font-size:10px;font-weight:600}
.strong{background:#064e3b;color:#6ee7b7}.buy{background:#1e3a8a;color:#93c5fd}.watch{background:#374151;color:#d1d5db}
.smart-money{background:#7c2d12;color:#fdba74;padding:2px 6px;border-radius:4px;font-weight:700;font-size:10px}
.risk-low{color:#10b981}.risk-medium{color:#f59e0b}.risk-high{color:#ef4444}
.pos{color:#10b981}.neg{color:#ef4444}
a{color:#4fd1c5;text-decoration:none}
.refresh{margin-left:auto;color:#6b7280;font-size:12px;font-weight:400}
</style></head><body>
<h1>🎯 SolSniper v3 <span style="font-size:13px;color:#fdba74;">🐋 Smart Money</span><span class="refresh" id="refresh">refreshing...</span></h1>
<div class="grid" id="stats"></div>

<h2>🐋 Smart Money — Live (last 15 min)</h2>
<table id="smart"><thead><tr><th>Token</th><th>Wallets</th><th>Total SOL</th><th>Age</th></tr></thead><tbody></tbody></table>

<h2>📊 Performance Stats</h2>
<div class="grid" id="performance"></div>

<h2>📡 Recent Signals (Top 50)</h2>
<table id="signals"><thead><tr>
<th>Time</th><th>Label</th><th>Symbol</th><th>Score</th><th>🐋</th><th>Risk</th>
<th>1h</th><th>Liq</th><th>MCap</th><th>Links</th>
</tr></thead><tbody></tbody></table>

<script>
const TOKEN=new URLSearchParams(location.search).get('token')||'';
async function api(p){return (await fetch(p+'?token='+TOKEN)).json()}
function fmt$(n){return '$'+Number(n).toLocaleString(undefined,{maximumFractionDigits:0})}
function badgeClass(l){return l==='STRONG BUY'?'strong':l==='BUY'?'buy':'watch'}
function riskClass(r){return 'risk-'+(r||'low').toLowerCase()}

async function refresh(){
 try{
  const s=await api('/api/stats');
  document.getElementById('stats').innerHTML=`
   <div class="card"><div class="label">Scans</div><div class="value">${s.scans}</div></div>
   <div class="card"><div class="label">Alerts</div><div class="value pos">${s.signals}</div></div>
   <div class="card highlight"><div class="label">🐋 Smart Money Signals</div><div class="value pos">${s.smart_money_signals}</div></div>
   <div class="card"><div class="label">Strong Buys</div><div class="value">${s.strong_buys}</div></div>
   <div class="card"><div class="label">Wallets Tracked</div><div class="value">${s.wallets_tracked}</div></div>
   <div class="card"><div class="label">Last Scan</div><div class="value" style="font-size:13px">${s.last_scan}</div></div>`;

  const sm=await api('/api/smart_money');
  document.querySelector('#smart tbody').innerHTML=sm.length?sm.map(x=>
   `<tr><td><a href="https://dexscreener.com/solana/${x.mint}" target="_blank"><code>${x.mint.slice(0,8)}...</code></a></td>
        <td><b>${x.wallet_count}</b></td><td>${x.total_sol.toFixed(2)}</td><td>${x.oldest_min.toFixed(0)}m</td></tr>`
  ).join(''):'<tr><td colspan="4" style="text-align:center;color:#6b7280">No smart money activity yet</td></tr>';

  const perf=await api('/api/performance');
  if (perf.total_tracked > 0) {
    document.getElementById('performance').innerHTML=`
     <div class="card"><div class="label">Tracked</div><div class="value">${perf.total_tracked}</div></div>
     <div class="card"><div class="label">Win Rate (1h)</div><div class="value pos">${perf.win_rate_1h}%</div></div>
     <div class="card"><div class="label">Avg PnL (1h)</div><div class="value ${perf.avg_pnl_1h>=0?'pos':'neg'}">${perf.avg_pnl_1h>=0?'+':''}${perf.avg_pnl_1h}%</div></div>
     <div class="card"><div class="label">Avg Peak PnL</div><div class="value pos">+${perf.avg_peak_pnl}%</div></div>`;
  } else {
    document.getElementById('performance').innerHTML='<div class="card"><div class="label">Stats</div><div class="value" style="font-size:14px">Need 1h+ of alerts</div></div>';
  }

  const sigs=await api('/api/signals');
  document.querySelector('#signals tbody').innerHTML=sigs.length?sigs.map(x=>
   `<tr><td>${(x.created_at||'').slice(11,16)}</td>
    <td><span class="badge ${badgeClass(x.label)}">${x.label}</span></td>
    <td><b>${x.symbol}</b></td><td>${x.score}</td>
    <td>${x.smart_money_count>0?'<span class="smart-money">🐋×'+x.smart_money_count+'</span>':''}</td>
    <td><span class="${riskClass(x.risk_level)}">${x.risk_level||'?'}</span></td>
    <td class="pos">+${Number(x.change_1h).toFixed(0)}%</td>
    <td>${fmt$(x.liquidity)}</td><td>${fmt$(x.mcap)}</td>
    <td><a href="${x.dex_url}" target="_blank">DEX</a> · <a href="https://rugcheck.xyz/tokens/${x.address}" target="_blank">RC</a></td></tr>`).join('')
   :'<tr><td colspan="10" style="text-align:center;color:#6b7280">No signals yet</td></tr>';

  document.getElementById('refresh').textContent='updated '+new Date().toLocaleTimeString();
 }catch(e){document.getElementById('refresh').textContent='error: '+e.message}
}
refresh();setInterval(refresh,5000);
</script></body></html>"""

@app.route("/")
def index():
    require_auth()
    return render_template_string(INDEX_HTML)

@app.route("/api/stats")
def api_stats():
    require_auth()
    s = db.get_summary_stats()
    s["wallets_tracked"] = len(smart_money.load_wallets())
    return jsonify(s)

@app.route("/api/signals")
def api_signals():
    require_auth()
    return jsonify(db.recent_signals(50))

@app.route("/api/smart_money")
def api_smart_money():
    require_auth()
    return jsonify(smart_money.top_recent_tokens(min_wallets=1, top_n=15))

@app.route("/api/performance")
def api_performance():
    require_auth()
    return jsonify(outcome_tracker.get_performance_stats())

if __name__ == "__main__":
    if not config.DASHBOARD_TOKEN:
        log.error("DASHBOARD_TOKEN not set"); raise SystemExit(1)
    log.info(f"Dashboard on 0.0.0.0:{config.DASHBOARD_PORT}")
    app.run(host="0.0.0.0", port=config.DASHBOARD_PORT, debug=False)
