"""SQLite persistence v3."""
import os
import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import List, Dict, Any

import config

@contextmanager
def db():
    os.makedirs(os.path.dirname(config.DB_PATH) or ".", exist_ok=True)
    conn = sqlite3.connect(config.DB_PATH, timeout=15, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def init_db():
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS signals (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            address     TEXT,
            symbol      TEXT,
            name        TEXT,
            label       TEXT,
            score       INTEGER,
            price       REAL,
            change_1h   REAL,
            liquidity   REAL,
            volume_1h   REAL,
            mcap        REAL,
            age_min     REAL,
            dex_url     TEXT,
            risk_level  TEXT,
            rug_data    TEXT,
            smart_money_count INTEGER DEFAULT 0,
            social_mentions   INTEGER DEFAULT 0,
            trending_climb    INTEGER DEFAULT 0,
            created_at  TEXT
        );
        CREATE TABLE IF NOT EXISTS seen_tokens (
            address     TEXT PRIMARY KEY,
            first_seen  TEXT
        );
        CREATE TABLE IF NOT EXISTS stats (
            key   TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_sig_created ON signals(created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_sig_smart ON signals(smart_money_count DESC);
        """)
        # safe migration: add `source` column if missing (per-source attribution)
        try:
            cols = [r["name"] for r in conn.execute("PRAGMA table_info(signals)").fetchall()]
            if "source" not in cols:
                conn.execute("ALTER TABLE signals ADD COLUMN source TEXT DEFAULT 'unknown'")
        except Exception:
            pass

def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

def has_seen(address: str) -> bool:
    with db() as conn:
        return conn.execute("SELECT 1 FROM seen_tokens WHERE address=?", (address,)).fetchone() is not None

def mark_seen(address: str):
    with db() as conn:
        conn.execute("INSERT OR IGNORE INTO seen_tokens(address, first_seen) VALUES(?,?)",
                     (address, now_iso()))

def prune_seen(keep_last: int = 5000):
    with db() as conn:
        conn.execute("""
            DELETE FROM seen_tokens WHERE address NOT IN (
                SELECT address FROM seen_tokens ORDER BY first_seen DESC LIMIT ?
            )""", (keep_last,))

def save_signal(s: Dict[str, Any]) -> int:
    """Returns the new signal_id."""
    with db() as conn:
        rug = s.get("rug_check") or {}
        sm = s.get("smart_money") or {}
        social = s.get("social") or {}
        velocity = s.get("velocity") or {}
        cur = conn.execute("""
            INSERT INTO signals(address, symbol, name, label, score, price,
                                change_1h, liquidity, volume_1h, mcap, age_min,
                                dex_url, risk_level, rug_data, smart_money_count,
                                social_mentions, trending_climb, source, created_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            s["address"], s["symbol"], s["name"], s["label"], s["score"],
            s["price"], s["change_1h"], s["liquidity"], s["volume_1h"],
            s["mcap"], s["age_min"], s.get("dex_url", ""),
            rug.get("risk_level", ""),
            json.dumps({"fails": rug.get("fails", []), "warnings": rug.get("warnings", [])}),
            sm.get("count", 0),
            social.get("mentions_estimate", 0),
            velocity.get("rank_change", 0),
            s.get("source", "unknown"),
            now_iso(),
        ))
        return cur.lastrowid

def recent_signals(limit: int = 50) -> List[Dict[str, Any]]:
    with db() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM signals ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]

def stat_inc(key: str, n: int = 1):
    with db() as conn:
        row = conn.execute("SELECT value FROM stats WHERE key=?", (key,)).fetchone()
        v = (int(row["value"]) if row else 0) + n
        conn.execute("INSERT OR REPLACE INTO stats(key, value) VALUES(?,?)", (key, str(v)))

def stat_get(key: str, default: str = "0") -> str:
    with db() as conn:
        row = conn.execute("SELECT value FROM stats WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

def stat_set(key: str, value: str):
    with db() as conn:
        conn.execute("INSERT OR REPLACE INTO stats(key, value) VALUES(?,?)", (key, value))

def get_summary_stats() -> Dict[str, Any]:
    return {
        "scans": int(stat_get("scans")),
        "signals": int(stat_get("signals")),
        "strong_buys": int(stat_get("strong_buys")),
        "smart_money_signals": int(stat_get("smart_money_signals")),
        "last_scan": stat_get("last_scan", "—"),
    }

def source_breakdown() -> list:
    """Per-source signal counts + avg score — attribution report."""
    with db() as conn:
        try:
            rows = conn.execute("""
                SELECT COALESCE(source,'unknown') AS source,
                       COUNT(*) AS n,
                       ROUND(AVG(score),1) AS avg_score,
                       SUM(CASE WHEN label LIKE '%SNIPER%' THEN 1 ELSE 0 END) AS snipers,
                       SUM(smart_money_count>0) AS with_smart
                FROM signals GROUP BY source ORDER BY n DESC
            """).fetchall()
            return [dict(r) for r in rows]
        except Exception:
            return []
